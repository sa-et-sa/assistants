# Champ de volume d'eau d'érable

## field-water-volume

### field_water_volume

- id: field_water_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### label

- fr: Quantité d'eau
- en: Water quantity
- es: Cantidad de agua

#### question

- fr: Quel est le volume d'eau d'érable?
- en: What is the volume of maple water?
- es: ¿Cuál es el volumen de agua de arce?

#### justification

- fr: Le volume d'eau d'érable nous permettra d'estimer la quantité résultante suite à la concentration.
- en: The volume of maple water will allow us to estimate the resulting quantity following the concentration.
- es: El volumen de agua de arce nos permitirá estimar la cantidad resultante después de la concentración.
