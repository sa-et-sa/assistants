# Champ de concentration en sucre cible

## field-correction-brix-target

### field_correction_brix_target

- id: field_correction_brix_target
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### question

- fr: Quelle est la concentration en sucre désirée ?
- en: What is the desired sugar concentration?
- es: ¿Cuál es la concentración de azúcar deseada?

#### justification

{{justification-brix-syrup-target}}

#### answer

{{answer-number-brix-syrup}}
