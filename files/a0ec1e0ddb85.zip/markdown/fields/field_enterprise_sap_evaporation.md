# Champ de récolte de sève de l'entreprise

## field-enterprise-sap-evaporation

### field_enterprise_sap_evaporation

- id: field_enterprise_sap_evaporation
- fieldType: yesno

#### label

- fr: Évaporation de la sève
- en: Sap evaporation
- es: Evaporación de savia

#### question

- fr: Est-ce que l'entreprise évapore la sève ?
- en: Does the company evaporate sap?
- es: ¿La empresa evapora savia?

#### justification

- fr: Si oui, nous ajouterons le module d'évaporation de sève à votre compte.
- en: If yes, we will add the sap evaporation module to your account.
- es: Si es así, agregaremos el módulo de evaporación de savia a su cuenta.
