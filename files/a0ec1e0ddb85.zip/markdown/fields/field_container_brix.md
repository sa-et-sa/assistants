# Champ de Brix du sirop

## field-container-brix

### field_container_brix

- id: field_container_brix
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix
- chartTypes: brix

#### label

{{label-brix-degree}}

#### question

{{question-brix-degree}}

#### justification

{{justification-specific-weight}}

#### answer

{{answer-number-brix-syrup}}
