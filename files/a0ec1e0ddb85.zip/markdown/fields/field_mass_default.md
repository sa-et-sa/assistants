# Champ de masse par défaut

## field-mass-default

### mass

- id: mass
- fieldType: decimal
- modifier: forCompute
- keyboardType: mass

#### label

- fr: Masse
- en: Mass
- es: Masa

#### question

- fr: Quelle est la masse à convertir?
- en: What is the mass to convert?
- es: ¿Cuál es la masa a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
