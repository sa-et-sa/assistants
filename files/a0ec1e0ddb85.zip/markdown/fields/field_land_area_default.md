# Champ de surface de terrain par défaut

## field-land-area-default

### land_area

- id: land_area
- fieldType: decimal
- modifier: forCompute
- keyboardType: landArea

#### label

- fr: Superficie
- en: Area
- es: Superficie

#### question

- fr: Quelle est la superficie à convertir?
- en: What is the area to convert?
- es: ¿Cuál es la superficie a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
