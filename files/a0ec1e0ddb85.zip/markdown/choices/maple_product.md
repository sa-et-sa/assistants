# maple_product

## name

- fr: Liste des produits d'érable
- en: List of maple products
- es: Lista de productos de arce

## fields

### kilogramButter

- id: kilogramButter
- fieldType: text

#### label

- fr: Beurre (kg)
- en: Butter (kg)
- es: Mantequilla (kg)

### lbsButter

- id: lbsButter
- fieldType: text

#### label

- fr: Beurre (lbs)
- en: Butter (lbs)
- es: Mantequilla (lbs)

### kilogramSnowTaffy

- id: kilogramSnowTaffy
- fieldType: text

#### label

- fr: Tire sur neige (kg)
- en: Snow taffy (kg)
- es: Azúcar en la nieve (kg)

### lbsSnowTaffy

- id: lbsSnowTaffy
- fieldType: text

#### label

- fr: Tire sur neige (lbs)
- en: Snow taffy (lbs)
- es: Azúcar en la nieve (lbs)

### kilogramSoftSugar

- id: kilogramSoftSugar
- fieldType: text

#### label

- fr: Pot de tire, sucre / bonbon mou (kg)
- en: Pot of taffy, soft sugar / soft candy (kg)
- es: Bote de azúcar, azúcar / dulce blando (kg)

### lbsSoftSugar

- id: lbsSoftSugar
- fieldType: text

#### label

- fr: Pot de tire, sucre / bonbon mou (lbs)
- en: Pot of taffy, soft sugar / soft candy (lbs)
- es: Bote de azúcar, azúcar / dulce blando (lbs)

### kilogramHardSugar

- id: kilogramHardSugar
- fieldType: text

#### label

- fr: Sucre dur (kg)
- en: Hard sugar (kg)
- es: Azúcar duro (kg)

### lbsHardSugar

- id: lbsHardSugar
- fieldType: text

#### label

- fr: Sucre dur (lbs)
- en: Hard sugar (lbs)
- es: Azúcar duro (lbs)

### kilogramGranulatedSugar

- id:kilogramGranulatedSugar
- fieldType: text

#### label

- fr: Sucre granulé (kg)
- en: Granulated sugar (kg)
- es: Azúcar granulado (kg)
  
### lbsGranulatedSugar

- id: lbsGranulatedSugar
- fieldType: text

#### label

- fr: Sucre granulé (lbs)
- en: Granulated sugar (lbs)
- es: Azúcar granulado (lbs)

### taffyAndOrButterCones

- id:taffyAndOrButterCones
- fieldType: text

#### label

- fr: Cornets de tire et/ou de beurre
- en: Taffy and/or butter cones
- es: Conos de azúcar y/o mantequilla
  
## output

- outputType: reference

### outputFormat

- fr: {name}
- en: {name}
- es: {name}
