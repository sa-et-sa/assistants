# pressure_converter

## icon

- name: {{button-pressure}}

## category

- type: calculator

## name

- fr: Pression
- en: Pressure
- es: Presión

## fields

{{field-pressure-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Converisseur d'unité de pression: kilopascal (kPa) et livre par pouce carré (psi).
- en: **{name}**{_newline}Pressure unit converter: kilopascal (kPa) and pound per square inch (psi).
- es: **{name}**{_newline}Conversor de unidades de presión: kilopascal (kPa) y libra por pulgada cuadrada (psi).
