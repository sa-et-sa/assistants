# weather_pressure_converter

## icon

- name: {{button-weather-pressure}}

## category

- type: calculator

## name

- fr: Pression météorologique
- en: Weather Pressure
- es: Presión meteorológica

## fields

{{field-weather-pressure-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de pression météorologique: kilopascal (kPa), hectopascal (hPa), pouce de mercure (inHg) et millibar (mbar).
- en: **{name}**{_newline}Weather pressure unit converter: kilopascal (kPa), hectopascal (hPa), inch of mercury (inHg) and millibar (mbar).
- es: **{name}**{_newline}Convertidor de unidades de presión meteorológica: kilopascal (kPa), hectopascal (hPa), pulgada de mercurio (inHg) y milibar (mbar).
