# volume_converter

## icon

- name: {{button-volume}}

## category

- type: calculator

## name

- fr: Volume
- en: Volume
- es: Conversión

## fields

{{field-volume-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de volume: litre (L), gallon impérial (gal imp.), gallon américain (gal US), litres (L) et tasses (tasses).
- en: **{name}**{_newline}Volume unit converter: liter (L), imperial gallon (gal imp.), US gallon (gal US), liters (L) and cups (cups).
- es: **{name}**{_newline}Convertidor de unidades de volumen: litro (L), galón imperial (gal imp.), galón estadounidense (gal US), litros (L) y tazas (tazas).
