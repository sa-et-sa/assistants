# poids_specifique

## icon

- name: {{button-specific-weight}}

## category

- type: calculator

## name

- fr: Poids spécifique
- en: Specific weight
- es: Peso específico

## fields

{{field-weight-brix}}

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer le poids spécifique d'une solution de sucre.
- en: {_title}Calculate the specific weight of a sugar solution.
- es: {_title}Calcular el peso específico de una solución de azúcar.
