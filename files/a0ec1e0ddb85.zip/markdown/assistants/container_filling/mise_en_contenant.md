# mise_en_contenant

## icon

- name: 🛢️

## category

- type: inventory

## name

- fr: Mise en contenant
- en: Container filling
- es: Llenado de contenedores

## computeTitle

- fr: Prix du sirop
- en: Syrup price
- es: Precio del jarabe

## fields

{{field-container-start-date}}

{{field-container-id}}

{{field-container-volume}}

{{field-container-brix}}

{{field-container-luminance}}

{{field-container-ppaq-defect}}

{{field-container-organic}}

## secondary-tools

### delete

## output

- outputType: reference

### outputFormat

- fr: **Numéro: {field_container_id}**{_newline} {field_container_volume} à {field_container_brix}{_newline}Luminance: {field_container_luminance}{_newline}Défaut de saveur: {field_container_ppaq_defect}
- en: **Number: {field_container_id}**{_newline} {field_container_volume} at {field_container_brix}{_newline}Luminance: {field_container_luminance}{_newline}Flavor defect: {field_container_ppaq_defect}
- es: **Número: {field_container_id}**{_newline} {field_container_volume} a {field_container_brix}{_newline}Luminancia: {field_container_luminance}{_newline}Defecto de sabor: {field_container_ppaq_defect}

### resultsFormat

- fr: {_title}Nombre de mise en contenant: {_count}
- en: {_title}Number of container filling: {_count}
- es: {_title}Número de llenado de contenedores: {_count}

### noResultFormat

- fr: {_title}Aucune mise en contenant pour la période.
- en: {_title}No container filling for the period.
- es: {_title}No hay llenado de contenedores para el período.
