---
title: Bluetooth no activado
ok-button: "Activar Bluetooth"
---

El Bluetooth no está activado. Por favor, actívelo primero para mostrar sus dispositivos.

Le redirigiremos a la configuración.
