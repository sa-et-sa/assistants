# pourquoi_lentailleur

## icon

- name: 🤔

## category

- type: other

## name

- fr: Pourquoi l°Entailleur ?
- en: Why the Entailleur?
- es: ¿Por qué el Entailleur?

## onboarding-fields

### pourquoi_degre

## output

### noResultFormat

- fr: {_title}Découvrez les nuances qui font toute la différence.
- en: {_title}Discover the nuances that make all the difference.
- es: {_title}Descubre las sutilezas que marcan la diferencia.
