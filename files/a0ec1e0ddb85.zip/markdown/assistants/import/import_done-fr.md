---
title: Importation terminée
ok-button: "Retour"
---

L'importation est terminée. Vous pouvez maintenant retourner à la page d'accueil.
