---
title: Error de Importación
ok-button: "Volver"
---

Ocurrió un error al importar el archivo. Por favor, asegúrate de haber seleccionado un archivo válido e inténtalo de nuevo. Si el problema persiste, contacta con el soporte.
