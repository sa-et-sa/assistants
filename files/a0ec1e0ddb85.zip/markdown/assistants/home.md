# home

## icon

- name: 🏠

## category

- type: other

## name

- fr: Accueil
- en: Home
- es: Inicio

## assistant-fields

### entreprise

- maxResults: {{parameter-max-enterprise}}

## primary-tools

### calculators

### unit_converter

## secondary-tools

### bluetooth

## modules

### import

### delete

### container_filling

## related-assistants

### hamburger
