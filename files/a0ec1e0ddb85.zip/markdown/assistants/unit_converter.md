# unit_converter

## icon

- name: {{button-conversion}}

## category

- type: other

## name

- fr: Convertisseur d'unités
- en: Unit Converter
- es: Convertidor de unidades

## fields

{{field-mass-default}}

{{field-volume-default}}

{{field-weather-pressure-default}}

{{field-pressure-default}}

{{field-long-distance-default}}

{{field-short-distance-default}}

{{field-temperature-default}}

{{field-land-area-default}}

## output

{{output-empty}}
