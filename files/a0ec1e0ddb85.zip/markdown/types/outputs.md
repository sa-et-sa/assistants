# Outputs

## output-empty

- outputType: none

### outputFormat

- fr: aucun
- en: none
- es: ninguno
