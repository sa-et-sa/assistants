# Generic Fields

## field-start-date

### field_start_date

- id: field_start_date
- fieldType: dateTime

#### answer

- answerType: dateTime

## field-organic-certification

### field_organic_certification

- id: field_organic_certification
- fieldType: yesno
- modifier: forCompute
