# Labels

## label-lentailleur

- fr: L°Entailleur
- en: L°Entailleur
- es: L°Entailleur

## label-brix-degree

- fr: {{brix-degree-fr}}
- en: {{brix-degree-en}}
- es: {{brix-degree-es}}
