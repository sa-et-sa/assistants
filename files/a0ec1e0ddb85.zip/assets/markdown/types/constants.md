# Constants

## number-default-precision

4

## brix-precision

1

## brix-water-minimal

0.1

## brix-water-maximal

10

## brix-concentrate-minimal

2

## brix-concentrate-maximal

50

## brix-syrup-minimal

66

## brix-syrup-maximal

70

## brix-syrup-target

66.5

## brix-degree-fr

Degré Brix (˚B) à 20˚C

## brix-degree-en

Brix degree (˚B) at 20˚C

## brix-degree-es

Grado Brix (˚B) a 20˚C
