# Answers

## answer-number-default-precision

- answerType: number

##### numberValidation

- precision: {{number-default-precision}}

## answer-number-brix-syrup

- answerType: number
  
##### numberValidation

- min: {{brix-syrup-minimal}}
- max: {{brix-syrup-maximal}}
- precision: {{brix-precision}}
- preFilledValue: {{brix-syrup-target}}

## answer-number-brix-all

- answerType: number
  
##### numberValidation

- min: {{brix-water-minimal}}
- max: {{brix-syrup-maximal}}
- precision: {{brix-precision}}

## answer-number-brix-concentration

- answerType: number
  
##### numberValidation

- min: {{brix-water-minimal}}
- max: {{brix-syrup-minimal}}
- precision: {{brix-precision}}

## answer-number-brix-concentration-target

- answerType: number
  
##### numberValidation

- min: {{brix-concentrate-minimal}}
- max: {{brix-syrup-maximal}}
- precision: {{brix-precision}}
