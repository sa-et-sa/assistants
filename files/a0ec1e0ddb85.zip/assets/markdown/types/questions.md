# Questions

## question-brix-degree

- fr: Quelle est le {{brix-degree-fr}} ?
- en: What is the {{brix-degree-en}}?
- es: ¿Cuál es el {{brix-degree-es}}?
