# Buttons

## button-ok

- fr: OK
- en: OK
- es: OK

## button-yes

- fr: Oui
- en: Yes
- es: Sí

## button-no

- fr: Non
- en: No
- es: No

## button-agree

- fr: D'accord
- en: Agree
- es: De acuerdo

## button-back

- fr: Retour
- en: Back
- es: Atrás

## button-help

- emoji: 🆘

## button-next

- emoji: ⏭

## button-submit

- emoji: 📤

## button-camera

- emoji: 📷

## button-keyboard

- emoji: ⌨️

## button-conversion

- emoji: 💱

## button-calculator

- emoji: 🧮

## button-justification

- emoji: 📖

## button-home

- emoji: 🏠

## button-user

- emoji: 👤

## button-enterprise

- emoji: 🏢

## button-bluetooth

- emoji: 📶

## button-device

- emoji: 🕹️

## button-network

- emoji: 🌐

## button-undefined

- emoji: 🪲

## button-delete

- emoji: ⬅️

## button-graphics

- emoji: 📊

## button-temperature

- emoji: 🌡️

## button-land-area

- emoji: 🏞️

## button-long-distance

- emoji: 🛤️

## button-short-distance

- emoji: 📏

## button-mass

- emoji: ⚖️

## button-pressure

- emoji: 🌊

## button-weather-pressure

- emoji: 🌦️

## button-volume

- emoji: 🧪

## button-maple-syrup-to-products

- emoji: 🍁

## button-products-to-maple-syrup

- emoji: 🍁

## button-density-correction

- emoji: 🚰

## button-specific-weight

- emoji: ⚖️
  
## button-ppaq-price

- emoji: 💲

## button-sap-syrup

- emoji: ⚗️
