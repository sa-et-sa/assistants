# Justifications

## justification-converter

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton {{button-submit}} pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the {{button-submit}} button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón {{button-submit}} para obtener el resultado.

## justification-brix-syrup-source

- fr: Cette concentration doit être supérieur à la concentration désirée. Les plages de valeurs admissibles sont de {{brix-syrup-minimal}} à {{brix-syrup-maximal}}, car il n'est pas recommandé de corriger un sirop dont la concentration est inférieure à {{brix-syrup-minimal}}.
- en: This concentration must be higher than the desired concentration. The acceptable value ranges are from {{brix-syrup-minimal}} to {{brix-syrup-maximal}}, as it is not recommended to correct a syrup with a concentration lower than {{brix-syrup-minimal}}.
- es: Esta concentración debe ser mayor que la concentración deseada. Los rangos de valores aceptables son de {{brix-syrup-minimal}} a {{brix-syrup-maximal}}, ya que no se recomienda corregir un jarabe con una concentración inferior a {{brix-syrup-minimal}}.

## justification-brix-syrup-target

- fr: Cette concentration doit être inférieure à la concentration du sirop à corriger. Les plages de valeurs admissibles sont de {{brix-syrup-minimal}} à {{brix-syrup-maximal}}, car il n'est pas recommandé de soumettre un sirop qui n'est pas dans cette plage de valeurs. **Si vous obtenez un nombre négatif**, cela signifie que vous devez retirer de l'eau du sirop plutôt que d'en ajouter.
- en: This concentration must be lower than the concentration of the syrup to be corrected. The acceptable value ranges are from {{brix-syrup-minimal}} to {{brix-syrup-maximal}}, as it is not recommended to submit a syrup that is not in this value range. If you get a negative number, it means you need to remove water from the syrup rather than add it.
- es: Esta concentración debe ser menor que la concentración del jarabe a corregir. Los rangos de valores aceptables son de {{brix-syrup-minimal}} a {{brix-syrup-maximal}}, ya que no se recomienda someter un jarabe que no esté en este rango de valores. Si obtiene un número negativo, significa que debe retirar agua del jarabe en lugar de agregarla.

## justification-specific-weight

- fr: Il est important de mesurer le degré brix à 20°C, notamment à l'aide d'un réfractomètre. De plus, le poids spécifique du sirop est calculé à l'aide d'une table de conversion mesurée à 20°C Référence: *Calcul du poids spécifique relatif (densité) d’une solution de sucre d’érable en fonction de sa concentration (°Brix) Par Gaston B. Allard ing., agr.*
- en: It is important to measure the Brix degree at 20°C, especially using a refractometer. In addition, the specific weight of the syrup is calculated using a conversion table measured at 20°C. Reference: *Calculation of the relative specific weight (density) of a maple sugar solution based on its concentration (°Brix) By Gaston B. Allard ing., agr.*
- es: Es importante medir el grado Brix a 20°C, especialmente utilizando un refractómetro. Además, el peso específico del jarabe se calcula utilizando una tabla de conversión medida a 20°C. Referencia: *Cálculo del peso específico relativo (densidad) de una solución de azúcar de arce en función de su concentración (°Brix) Por Gaston B. Allard ing., agr.*

## justification-brix-source

- fr: Il s'agit de la concentration en sucre de l'eau d'érable avant la concentration. Les valeurs admissibles sont de {{brix-water-minimal}} à {{brix-syrup-minimal}}. **N'oubliez pas de faire l'ajustement à la température si nécessaire.**
- en: This is the sugar concentration of the maple water before concentration. The acceptable values are from {{brix-water-minimal}} to {{brix-syrup-minimal}}. **Don't forget to make the temperature adjustment if necessary.**
- es: Esta es la concentración de azúcar del agua de arce antes de la concentración. Los valores aceptables son de {{brix-water-minimal}} a {{brix-syrup-minimal}}. **No olvide hacer el ajuste de temperatura si es necesario.**

## justification-brix-target

- fr: Il s'agit du degré Brix souhaité de l'eau d'érable que vous souhaitez obtenir. Les valeurs admissibles sont de {{brix-concentrate-minimal}} à {{brix-syrup-maximal}}. **Si vous saisissiez une valeur inférieure à celle de la concentration de l'eau d'érable, le calcul ne sera pas valide.**
- en: This is the desired Brix degree of the maple water you want to obtain. The acceptable values are from {{brix-concentrate-minimal}} to {{brix-syrup-maximal}}. **If you enter a value lower than the concentration of the maple water, the calculation will not be valid.**
- es: Este es el grado Brix deseado del agua de arce que desea obtener. Los valores aceptables son de {{brix-concentrate-minimal}} a {{brix-syrup-maximal}}. **Si ingresa un valor inferior a la concentración del agua de arce, el cálculo no será válido.**
