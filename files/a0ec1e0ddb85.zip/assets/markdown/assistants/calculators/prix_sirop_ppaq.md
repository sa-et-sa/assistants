# prix_sirop_ppaq

## icon

- name: {{button-ppaq-price}}

## category

- type: calculator

## name

- fr: Prix du sirop PPAQ
- en: PPAQ syrup price
- es: Precio del jarabe PPAQ

## fields

{{field-container-volume}}

{{field-container-brix}}

{{field-container-luminance}}

{{field-container-ppaq-defect}}

{{field-container-organic}}

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer le prix du sirop selon la convention de mise en marché des PPAQ.
- en: {_title}Calculate the price of the syrup according to the PPAQ marketing convention.
- es: {_title}Calcular el precio del jarabe según la convención de comercialización de PPAQ.
