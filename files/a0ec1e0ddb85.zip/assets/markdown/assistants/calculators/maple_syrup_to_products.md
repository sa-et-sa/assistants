# maple_syrup_to_products

## icon

- name: {{button-maple-syrup-to-products}}

## category

- type: calculator

## name

- fr: Sirop en produits de l'érable
- en: Maple syrup to products
- es: Jarabe de arce a productos

## fields

### field-container-volume

- id: field_container_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: mapleProductQuantity

#### label

- fr: Volume de sirop
- en: Syrup volume
- es: Volumen de jarabe

#### question

- fr: Quel est la quantité du sirop dont vous diposez pour faire des produits ?
- en: What is the amount of syrup available for making products?
- es: ¿Cuál es la cantidad de jarabe disponible para hacer productos?

#### justification

- fr: À partir de cette quantité nous allons vous donner

#### answer

- answerType: number

##### numberValidation

- precision: 2

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Pour une quantité donnée de sirop, déterminer la quantité de produits qui peuvent être fabriqués:{_newline}Tire sur neige ou en pot, sucre mou, dur ou granulé, beurre ou cornets de tire ou de beurre, etc.
- en: **{name}**{_newline}For a given quantity of syrup, determine the quantity of products that can be made:{_newline}Taffy on snow or in a pot, soft, hard or granulated sugar, butter or taffy or butter cones, etc.
- es: **{name}**{_newline}Para una cantidad dada de jarabe, determine la cantidad de productos que se pueden hacer:{_newline}Taffy en la nieve o en una olla, azúcar blando, duro o granulado, mantequilla o conos de taffy o mantequilla, etc.
