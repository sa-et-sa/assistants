# correction_densite_sirop

## icon

- name: {{button-density-correction}}

## category

- type: calculator

## name

- fr: Correction de la densité sirop
- en: Syrup density correction
- es: Corrección de la densidad del jarabe

## fields

{{field-correction-brix-source}}

{{field-correction-volume}}

{{field-correction-brix-target}}

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer l'eau à ajouter pour diminuer la densité du sirop.
- en: {_title}Calculate the water to add to decrease the syrup density.
- es: {_title}Calcular el agua a añadir para disminuir la densidad del jarabe.
