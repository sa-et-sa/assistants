# seve_en_sirop

## icon

- name: {{button-sap-syrup}}

## category

- type: calculator

## name

- fr: Concentration eau en sirop
- en: Sap concentration in syrup
- es: Concentración de savia en jarabe

## fields

### field_water_brix_source

- id: field_water_brix_source
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

{{label-brix-degree}}

#### question

{{question-brix-degree}}

#### justification

{{justification-brix-source}}.

#### answer

{{answer-number-brix-concentration}}

### field_water_volume

- id: field_water_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### label

- fr: Quantité d'eau
- en: Water quantity
- es: Cantidad de agua

#### question

- fr: Quel est le volume d'eau d'érable?
- en: What is the volume of maple water?
- es: ¿Cuál es el volumen de agua de arce?

#### justification

- fr: Le volume d'eau d'érable nous permettra d'estimer la quantité résultante suite à la concentration.
- en: The volume of maple water will allow us to estimate the resulting quantity following the concentration.
- es: El volumen de agua de arce nos permitirá estimar la cantidad resultante después de la concentración.

### field_water_brix_target

- id: field_water_brix_target
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

- fr: {{brix-degree-fr}} désiré
- en: Desired {{brix-degree-en}}
- es: {{brix-degree-es}} deseado

#### question

- fr: Quelle est le {{brix-degree-fr}} désiré ?
- en: What is the desired {{brix-degree-en}}?
- es: ¿Cuál es el {{brix-degree-es}} deseado?

#### justification

{{justification-brix-target}}

#### answer

{{answer-number-brix-concentration-target}}

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer la quantité de sirop ou de concentré que donnera une quantité d'eau d'érable ou de concentré.
- en: {_title}Calculate the quantity of syrup or concentrate that will result from a quantity of maple water or concentrate.
- es: {_title}Calcular la cantidad de jarabe o concentrado que resultará de una cantidad de agua de arce o concentrado.
