---
title: Welcome to L˚Entailleur!
ok-button: {{button-agree}}
---

L˚Entailleur is an application dedicated to maple syrup production that allows you to

1. Perform unit conversions {{button-conversion}}
2. Make various calculations applied to maple syrup production {{button-calculator}}
3. Track your production data {{button-graphics}}
4. And use the ranking report to quickly detect anomalies

Click the **{{button-agree}}** button to continue.
