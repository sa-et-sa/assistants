
# lot

## icon

- name: {{button-undefined}}

## category

- type: inventory

## name

- fr: Lots
- en: Lots
- es: Lotes
  
## fields

### superficie

- id : superficie
- fieldType: decimal
- keyboardType: landArea

#### answer

- answerType: number

##### numberValidation

- precision: 2

#### label

- fr: Superficie du lot
- en: Lot area
- es: Superficie del lote

#### question

- fr: Quelle est la superficie de votre lot ?
- en: What is the area of your lot?
- es: ¿Cuál es la superficie de su lote?

### entailles

- id : entailles
- fieldType: integer

#### answer

- answerType: number

#### label

- fr: Nombre d'entailles
- en: Number of taps
- es: Número de entalladuras

#### question

- fr: Combien d'entailles sur votre lot ?
- en: How many taps on your lot?
- es: ¿Cuántas entalladuras en su lote?

## output

{{output-empty}}
