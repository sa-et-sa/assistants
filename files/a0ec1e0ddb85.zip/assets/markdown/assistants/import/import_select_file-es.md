---
title: Importar Archivo
ok-button: "Abrir Archivo"
---

Necesitas seleccionar un archivo exportado previamente. Haz clic en el botón de abajo para abrir el archivo.
