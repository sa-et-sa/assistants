---
title: Erreur d'importation
ok-button: "Retour"
---

Un erreur est survenue lors de l'importation du fichier. Veuillez vérifier que vous avez bien sélectionné un fichier valide et réessayez. Si le problème persiste, veuillez contacter le support.
