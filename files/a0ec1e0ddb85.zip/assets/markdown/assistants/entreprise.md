
# entreprise

## icon

- name: 🏢

## category

- type: inventory

## name

- fr: Entreprise
- en: Company
- es: Empresa
  
## fields

{{field-enterprise-name}}

{{field-enterprise-organic}}

{{field-enterprise-container-filling}}

## secondary-tools

### import

## output

- outputType: reference

### outputFormat

- fr: **{field_enterprise_name}**{_newline}Certification biologique : {field_organic_certification}
- en: **{field_enterprise_name}**{_newline}Organic certification: {field_organic_certification}
- es: **{field_enterprise_name}**{_newline}Certificación orgánica: {field_organic_certification}

### noResultFormat

- fr: {_title}Vous devez d'abord saisir vos informations d'entreprise afin de continuer. Cliquez ici pour le faire !
- en: {_title}You must first enter your company information in order to continue. Click here to do so!
- es: {_title}Primero debe ingresar la información de su empresa para continuar. ¡Haga clic aquí para hacerlo!
