# user

## icon

- name: {{button-user}}

## category

- type: other

## name

- fr: Utilisateur
- en: User
- es: Usuario

## fields

### id

- id: id
- fieldType: text
- modifier: constant

#### label

- fr: Courriel
- en: Email
- es: Correo electrónico

#### question

- fr: Quel est votre courriel ?
- en: What is your email?
- es: ¿Cuál es su correo electrónico?

#### answer

- answerType: string

##### values

- value: <allo@sa-et-sa.com>

## onboarding-fields

### user_welcome

## related-assistants

### home
