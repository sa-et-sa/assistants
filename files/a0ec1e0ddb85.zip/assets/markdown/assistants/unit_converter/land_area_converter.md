# land_area_converter

## icon

- name: {{button-land-area}}

## category

- type: calculator

## name

- fr: Superficie
- en: Land Area
- es: Área de terreno

## fields

{{field-land-area-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de superficie: hectares (ha), acres (acre), mètres carrés (m²), pieds carrés (ft²).
- en: **{name}**{_newline}Land area unit converter: hectares (ha), acres, square meters (m²), square feet (ft²).
- es: **{name}**{_newline}Conversor de unidades de área de terreno: hectáreas (ha), acres, metros cuadrados (m²), pies cuadrados (ft²).
