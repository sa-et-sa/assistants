# temperature_converter

## icon

- name: {{button-temperature}}

## category

- type: calculator

## name

- fr: Température
- en: Temperature
- es: Temperatura

## fields

{{field-temperature-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de température: Celsius (°C) et Fahrenheit (°F).
- en: **{name}**{_newline}Temperature Converter: Celsius (°C) and Fahrenheit (°F).
- es: **{name}**{_newline}Convertidor de unidades de temperatura: Celsius (°C) y Fahrenheit (°F).
