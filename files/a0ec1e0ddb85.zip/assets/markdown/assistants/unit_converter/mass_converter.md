# mass_converter

## icon

- name: {{button-mass}}

## category

- type: calculator

## name

- fr: Masse
- en: Mass
- es: Masa

## fields

{{field-mass-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de masse: kilogrammes (kg), livres (lb), onces (oz), grammes (g).
- en: **{name}**{_newline}Mass Converter: kilograms (kg), pounds (lb), ounces (oz), grams (g).
- es: **{name}**{_newline}Convertidor de unidades de masa: kilogramos (kg), libras (lb), onzas (oz), gramos (g).
