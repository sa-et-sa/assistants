# long_distance_converter

## icon

- name: {{button-long-distance}}

## category

- type: calculator

## name

- fr: Distance longue
- en: Long Distance
- es: Larga distancia

## fields

{{field-long-distance-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de distance longue: kilomètres (km) et milles (mi).
- en: **{name}**{_newline}Long Distance Converter: kilometers (km) and miles (mi).
- es: **{name}**{_newline}Convertidor de distancia larga: kilómetros (km) y millas (mi).
