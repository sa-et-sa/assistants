# short_distance_converter

## icon

- name: {{button-short-distance}}

## category

- type: calculator

## name

- fr: Distance courte
- en: Short Distance
- es: Corta distancia

## fields

{{field-short-distance-default}}

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de distance courte: centimètres (cm), mètres (m), pieds (ft) et pouces (in).
- en: **{name}**{_newline}Short Distance Converter: centimeters (cm), meters (m), feet (ft), inches (in).
- es: **{name}**{_newline}Convertidor de unidades de distancia corta: centímetros (cm), metros (m), pies (ft), pulgadas (in).
