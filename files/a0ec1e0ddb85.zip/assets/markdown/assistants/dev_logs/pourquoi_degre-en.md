---
title: Why the degree (°) ?
ok-button: "Suivant"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec purus auctor, ultricies nunc in, tincidunt nunc.
