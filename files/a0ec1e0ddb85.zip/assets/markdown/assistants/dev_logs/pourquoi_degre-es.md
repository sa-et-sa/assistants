---
title: ¿Por qué el grado (°)?
ok-button: "Suivant"
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec purus auctor, ultricies nunc in, tincidunt nunc.
