# evaporateur

## category

- type: equipment

## icon

- name: 🔥

## name

- fr: Évaporation
- en: Evaporation
- es: Evaporación

## fields

### brix_entree_evaporateur

- id: brix_entree_evaporateur
- fieldType: decimal
- keyboardType: brix
- chartTypes: brix

#### answer

- answerType: number

##### numberValidation

- min: 0
- max: 30
- step: 0.5
- precision: 1
- preFilledValue: 15

#### label

- fr: Degré Brix (˚B) en entrée
- en: Brix degree (˚B) at the entrance
- es: Grado Brix (˚B) en la entrada

#### question

- fr: Quel est le degré Brix (˚B) en entrée ?
- en: What is the Brix degree (˚B) at the entrance?
- es: ¿Cuál es el grado Brix (˚B) en la entrada?

### brix_transfert

- id: brix_transfert
- fieldType: decimal
- keyboardType: brix
- chartTypes: brix

#### answer

- answerType: number

##### numberValidation

- min: 30
- max: 60
- step: 0.5
- precision: 1
- preFilledValue: 45

#### label

- fr: Degré Brix (˚B) du transfert
- en: Brix degree (˚B) of transfer
- es: Grado Brix (˚B) de transferencia

#### question

- fr: Quel est le degré Brix (˚B) du transfert plis/plat ?
- en: What is the Brix degree (˚B) of transfer folds/flat?
- es: ¿Cuál es el grado Brix (˚B) de transferencia pliegues/plano?

### hauteur_plis

- id: hauteur_plis
- fieldType: decimal
- keyboardType: shortDistance

#### label

- fr: Hauteur de sève fond à plis
- en: Height of sap folded bottom
- es: Altura de la savia fondo con pliegues

#### question

- fr: Quelle est la hauteur de sève pour les pannes à plis ?
- en: What is the height of the sap for the pans with folds?
- es: ¿Cuál es la altura de la savia para las cacerolas con pliegues?

### hauteur_plat

- id: hauteur_plat
- fieldType: decimal
- keyboardType: shortDistance

#### label

- fr: Hauteur de sève fond plat
- en: Height of sap flat bottom
- es: Altura de la savia fondo plano

#### question

- fr: Quelle est la hauteur de sève pour les pannes à fond plat ?
- en: What is the height of the sap for the flat bottom pans?
- es: ¿Cuál es la altura de la savia para las cacerolas de fondo plano?

## output

- outputType: reference

### outputFormat

- fr: {_title}Dernière évaporation: {start_date}
- en: {_title}Evaporation session
- es: {_title}Sesión de evaporación
