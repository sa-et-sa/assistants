---
title: Deletion
ok-button: "Confirm"
cancel-button: "Cancel"
---

Do you confirm the deletion of the item?
