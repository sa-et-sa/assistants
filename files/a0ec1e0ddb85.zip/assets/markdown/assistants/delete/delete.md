# delete

## category

- type: other

## icon

- name: 🪓

## name

- fr: Suppression
- en: Delete
- es: Eliminación

## onboarding-fields

### delete_confirm

## output

- outputType: reference

### outputFormat

- fr: **{name}**
- en: **{name}**
- es: **{name}**
