# hamburger

## icon

- name: ☰

## category

- type: other

## name

{{label-lentailleur}}

## assistant-fields

### license/license
