# container_filling

## category

- type: other

## icon

- name: 🛢️

## name

- fr: Mise en contenant contenant
- en: Container filling
- es: Llenado de contenedores

## related-assistants

### mise_en_contenant
