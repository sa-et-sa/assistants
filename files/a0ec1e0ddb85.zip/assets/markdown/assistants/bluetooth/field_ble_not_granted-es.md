---
title: Permiso de Bluetooth no concedido
ok-button: "Solicitar permiso"
---

Solicitaremos permiso para acceder a Bluetooth. Si se niega, no podremos mostrar sus dispositivos.
