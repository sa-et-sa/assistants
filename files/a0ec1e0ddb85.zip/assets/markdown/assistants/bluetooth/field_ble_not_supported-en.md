---
title: Bluetooth Not Supported
ok-button: "Back"
---

Your device does not support Bluetooth. You will not be able to display your devices.
