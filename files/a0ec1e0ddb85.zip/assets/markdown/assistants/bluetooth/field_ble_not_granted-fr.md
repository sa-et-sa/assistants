---
title: Permission Bluetooth non accordée
ok-button: "Demander la permission"
---

Nous allons vous demander la permission d'accéder au Bluetooth. Si vous refusez, nous ne pourrons pas afficher vos appareils.
