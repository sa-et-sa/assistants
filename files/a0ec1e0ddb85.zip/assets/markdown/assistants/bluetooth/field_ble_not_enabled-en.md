---
title: Bluetooth Not Enabled
ok-button: "Enable Bluetooth"
---

Bluetooth is not enabled. Please enable it first to display your devices.

We will redirect you to the settings.
