---
title: Bluetooth no compatible
ok-button: "Volver"
---

Su dispositivo no admite Bluetooth. No podrá mostrar sus dispositivos.
