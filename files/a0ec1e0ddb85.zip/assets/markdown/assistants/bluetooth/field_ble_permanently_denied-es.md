---
title: Permiso de Bluetooth denegado permanentemente
ok-button: "Redirigir a la configuración"
---

Ha denegado permanentemente el permiso para acceder a Bluetooth. No podremos mostrar sus dispositivos.

Le redirigiremos a la configuración. Deberá otorgarnos permisos para acceder a Bluetooth o dispositivos cercanos.
