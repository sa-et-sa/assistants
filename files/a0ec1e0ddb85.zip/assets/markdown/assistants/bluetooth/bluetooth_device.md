# bluetooth_device

- version:  0.0.1

## category

- type: other

## icon

- name: {{button-device}}

## name

- fr: Appareil Bluetooth
- en: Bluetooth Device
- es: Dispositivo Bluetooth

## fields

{{field-ble-device-name}}

{{field-ble-device-rssi}}

{{field-ble-device-last-seen}}

## output

- outputType: reference

### outputFormat

- fr: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Dernière connexion: {field_ble_device_last_seen}
- en: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Last seen: {field_ble_device_last_seen}
- es: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Última conexión: {field_ble_device_last_seen}
