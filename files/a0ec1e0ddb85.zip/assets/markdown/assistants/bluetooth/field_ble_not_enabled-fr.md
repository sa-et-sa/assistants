---
title: Bluetooth non activé
ok-button: "Activer le Bluetooth"
---

Le Bluetooth n'est pas activé. Veuillez d'abord l'activer afin d'afficher vos appareils.

Nous allons vous rediriger vers les paramètres.
