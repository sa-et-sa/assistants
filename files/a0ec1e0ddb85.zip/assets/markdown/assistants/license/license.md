# license

## icon

- name: {{button-user}}

## category

- type: other

## name

- fr: Licences
- en: Licenses
- es: Licencias

## onboarding-fields

### license_list
