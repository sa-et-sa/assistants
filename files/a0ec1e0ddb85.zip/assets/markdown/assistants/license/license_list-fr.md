---
title: Licences
ok-button: {{button-back}}
---

{{license-content}}
