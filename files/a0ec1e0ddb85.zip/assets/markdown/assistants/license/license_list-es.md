---
title: Licencias
ok-button: {{button-back}}
---

{{license-content}}
