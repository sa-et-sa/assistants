---
title: Licenses
ok-button: {{button-back}}
---

{{license-content}}
