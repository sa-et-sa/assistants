# Champ de nom de l'entreprise

## field-enterprise-name

### field_enterprise_name

- id: field_enterprise_name
- fieldType: text

#### answer

- answerType: string

#### label

- fr: Nom de l'entreprise
- en: Company name
- es: Nombre de la empresa

#### question

- fr: Quel est le nom de votre entreprise ?
- en: What is the name of your company?
- es: ¿Cuál es el nombre de su empresa?

#### justification

- fr: Nous vous demandons cette information afin de personnaliser votre expérience. Nous ne partagerons pas cette information sans vous en informer.
- en: We ask for this information to personalize your experience. We will not share this information without informing you.
- es: Solicitamos esta información para personalizar su experiencia. No compartiremos esta información sin informarle.
