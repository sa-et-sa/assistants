# Champ de prime biologique

## field-enterprise-organic

{{field-organic-certification}}

#### label

- fr: Certification biologique
- en: Organic certification
- es: Certificación orgánica

#### question

- fr: Est-ce que votre entreprise est certifiée biologique ?
- en: Is your company certified organic?
- es: ¿Su empresa está certificada como orgánica?

#### justification

- fr: Cette information nous permet de pré-remplir les champs de certification biologique.
- en: This information allows us to pre-fill the organic certification fields.
- es: Esta información nos permite rellenar automáticamente los campos de certificación orgánica.
