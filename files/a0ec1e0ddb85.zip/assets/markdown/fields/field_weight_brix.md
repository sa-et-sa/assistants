# Degré Brix pour le poids spécifique

## field-weight-brix

### field_weight_brix

- id: field_weight_brix
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

{{label-brix-degree}}

#### question

{{question-brix-degree}}

#### justification

{{justification-specific-weight}}

#### answer

{{answer-number-brix-all}}
