# Champ de nombre d'entailles

## field-entreprise-taps

### field_entreprise_taps

- id: field_entreprise_taps
- fieldType: integer

#### label

- fr: Nombre d'entailles
- en: Number of taps
- es: Número de entalladuras

#### question

- fr: Combien d'entailles votre entreprise possède-t-elle ?
- en: How many taps does your company have?
- es: ¿Cuántas entalladuras tiene su empresa?

#### justification

- fr: Cette information nous permettra de calculer le rendement de votre entreprise en nombres de livres à l'entaille.
- en: This information will allow us to calculate the yield of your company in pounds per tap.
- es: Esta información nos permitirá calcular el rendimiento de su empresa en libras por entalladura.
