# Champ de superficie de l'entreprise

## field-entreprise-surface

### field_entreprise_surface

- id: field_entreprise_surface
- fieldType: decimal
- keyboardType: landArea

#### label

- fr: Superficie
- en: Area
- es: Superficie

#### question

- fr: Quelle est la superficie de votre entreprise ?
- en: What is the area of your company?
- es: ¿Cuál es la superficie de su empresa?

#### justification

- fr: Cette information nous permettra de calculer le rendement de votre entreprise en nombres de livres à l'hectare.
- en: This information will allow us to calculate the yield of your company in pounds per hectare.
- es: Esta información nos permitirá calcular el rendimiento de su empresa en libras por hectárea.
