# Champ de volume du contenant

## field-container-volume

### field_container_volume

- id: field_container_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume
- chartTypes: productionValue, averagePrice

#### label

- fr: Volume de sirop
- en: Syrup volume
- es: Volumen de jarabe

#### question

- fr: Quel est le volume du sirop ?
- en: What is the syrup volume?
- es: ¿Cuál es el volumen del jarabe?

#### answer

- answerType: number

##### numberValidation

- precision: 2
