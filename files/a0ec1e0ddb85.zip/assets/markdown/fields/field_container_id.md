# Champ de numéro du contenant

## field-container-id

### field_container_id

- id: field_container_id
- fieldType: barcode

#### label

- fr: Numéro du contenant
- en: Container number
- es: Número del contenedor

#### question

- fr: Quel est le numéro du contenant ?
- en: What is the container number?
- es: ¿Cuál es el número del contenedor?

#### justification

- fr: Le numéro du contenant est important pour la traçabilité. De plus, il nous permettra de faire l'association avec le rapport de classement du sirop. Si le contenant possède un code-barres, vous pouvez le scanner. S'il n'en possède pas, vous pouvez le saisir manuellement à l'aide du bouton {{button-keyboard}}.
- en: The container number is important for traceability. In addition, it will allow us to associate it with the syrup grading report. If the container has a barcode, you can scan it. If it does not have one, you can enter it manually using the {{button-keyboard}} button.
- es: El número del contenedor es importante para la trazabilidad. Además, nos permitirá asociarlo con el informe de clasificación del jarabe. Si el contenedor tiene un código de barras, puede escanearlo. Si no tiene uno, puede ingresarlo manualmente usando el botón {{button-keyboard}}.
