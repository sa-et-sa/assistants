# Champ de pression atmosphérique par défaut

## field-weather-pressure-default

### weather_pressure

- id: weather_pressure
- fieldType: decimal
- modifier: forCompute
- keyboardType: weatherPressure

#### label

- fr: Pression atmosphérique
- en: Atmospheric Pressure
- es: Presión atmosférica

#### question

- fr: Quelle est la pression atmosphérique à convertir?
- en: What is the atmospheric pressure to convert?
- es: ¿Cuál es la presión atmosférica a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
