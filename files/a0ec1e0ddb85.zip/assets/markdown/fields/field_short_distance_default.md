# Champ de distance courte par défaut

## field-short-distance-default

### short_distance

- id: short_distance
- fieldType: decimal
- modifier: forCompute
- keyboardType: shortDistance

#### label

- fr: Distance courte
- en: Short Distance
- es: Distancia corta

#### question

- fr: Quelle est la distance courte à convertir?
- en: What is the short distance to convert?
- es: ¿Cuál es la distancia corta a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
