# Champ de température par défaut

## field-temperature-default

### temperature

- id: temperature
- fieldType: decimal
- modifier: forCompute
- keyboardType: temperature

#### label

- fr: Température
- en: Temperature
- es: Temperatura

#### question

- fr: Quelle est la température à convertir?
- en: What is the temperature to convert?
- es: ¿Cuál es la temperatura a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
