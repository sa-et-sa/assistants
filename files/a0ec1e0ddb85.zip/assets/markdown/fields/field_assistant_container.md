# Champs assistant pour la mise en contenant PPAQ

## field-assistant-container

### field_assistant_container

- id: field_assistant_container
- fieldType: assistant

#### linkedAssistant

- id: mise_en_contenant
- maxResults: {{parameter-max-packages}}
