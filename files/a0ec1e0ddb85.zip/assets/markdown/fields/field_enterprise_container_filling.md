# Champ de récolte de sève de l'entreprise

## field-enterprise-container-filling

### field_enterprise_container_filling

- id: field_enterprise_container_filling
- fieldType: yesno

#### label

- fr: Mise en contenant
- en: Container filling
- es: Llenado de contenedores

#### question

- fr: Est-ce que l'entreprise effectue la mise en contenant ?
- en: Does the company perform container filling?
- es: ¿La empresa realiza el llenado de contenedores ?

#### justification

- fr: Si oui, nous ajouterons le module de récolte de sève à votre compte.
- en: If yes, we will add the sap harvesting module to your account.
- es: Si es así, agregaremos el módulo de cosecha de savia a su cuenta.
