# Champ de force du signal reçu (RSSI) de l'appareil Bluetooth

## field-ble-device-rssi

### field_ble_device_rssi

- id: field_ble_device_rssi
- fieldType: integer
  
#### question

- fr: RSSI
- en: RSSI
- es: RSSI
  