# Champ de concentration en sucre de l'eau d'érable

## field-water-brix-source

### field_water_brix_source

- id: field_water_brix_source
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

{{label-brix-degree}}

#### question

{{question-brix-degree}}

#### justification

{{justification-brix-source}}.

#### answer

{{answer-number-brix-concentration}}
