# Champ de distance longue par défaut

## field-long-distance-default

### long_distance

- id: long_distance
- fieldType: decimal
- modifier: forCompute
- keyboardType: longDistance

#### label

- fr: Distance longue
- en: Long Distance
- es: Distancia larga

#### question

- fr: Quelle est la distance longue à convertir?
- en: What is the long distance to convert?
- es: ¿Cuál es la distancia larga a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
