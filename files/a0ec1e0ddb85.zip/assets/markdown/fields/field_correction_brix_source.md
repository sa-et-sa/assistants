# Champ de concentration en sucre source

## field-correction-brix-source

### field_correction_brix_source

- id: field_correction_brix_source
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### question

- fr: Quelle est la concentration en sucre?
- en: What is the sugar concentration?
- es: ¿Cuál es la concentración de azúcar?

#### justification

{{justification-brix-syrup-source}}.

#### answer

{{answer-number-brix-syrup}}
