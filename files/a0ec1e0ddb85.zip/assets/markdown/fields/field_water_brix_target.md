# Champ de concentration en sucre cible

## field-water-brix-target

### field_water_brix_target

- id: field_water_brix_target
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

- fr: {{brix-degree-fr}} désiré
- en: Desired {{brix-degree-en}}
- es: {{brix-degree-es}} deseado

#### question

- fr: Quelle est le {{brix-degree-fr}} désiré ?
- en: What is the desired {{brix-degree-en}}?
- es: ¿Cuál es el {{brix-degree-es}} deseado?

#### justification

{{justification-brix-target}}

#### answer

{{answer-number-brix-concentration-target}}
