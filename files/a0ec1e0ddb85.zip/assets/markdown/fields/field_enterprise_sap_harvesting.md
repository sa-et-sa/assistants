# Champ de récolte de sève de l'entreprise

## field-enterprise-sap-harvesting

### field_enterprise_sap_harvesting

- id: field_enterprise_sap_harvesting
- fieldType: yesno

#### label

- fr: Récolte de sève
- en: Sap harvesting
- es: Cosecha de savia

#### question

- fr: Est-ce que l'entreprise récolte de la sève ?
- en: Does the company harvest sap?
- es: ¿La empresa cosecha savia?

#### justification

- fr: Si oui, nous ajouterons le module de récolte de sève à votre compte.
- en: If yes, we will add the sap harvesting module to your account.
- es: Si es así, agregaremos el módulo de cosecha de savia a su cuenta.
