# Champ de nom d'appareil Bluetooth

## field-ble-device-name

### field_ble_device_name

- id: field_ble_device_name
- fieldType: text

#### question

- fr: Nom
- en: Name
- es: Nombre
