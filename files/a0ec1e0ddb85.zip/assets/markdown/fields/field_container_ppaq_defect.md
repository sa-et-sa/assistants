# Champ de défaut de saveur du sirop

## field-container-ppaq-defect

### field_container_ppaq_defect

- id: field_container_ppaq_defect
- fieldType: choices
- choiceSource: defaut_saveur
- modifier: forCompute

#### label

- fr: Défaut de saveur
- en: Flavor defect
- es: Defecto de sabor

#### question

- fr: Avez-vous détecté un défaut de saveur ?
- en: Did you detect a flavor defect?
- es: ¿Detectó un defecto de sabor?

#### justification

- fr: Les défauts de saveur peuvent être causés par une mauvaise manipulation du sirop ou par une contamination. Ils peuvent affecter la qualité et le prix du sirop.
- en: Flavor defects can be caused by improper syrup handling or contamination. They can affect the quality and price of the syrup.
- es: Los defectos de sabor pueden ser causados por una manipulación incorrecta del jarabe o por contaminación. Pueden afectar la calidad y el precio del jarabe.
