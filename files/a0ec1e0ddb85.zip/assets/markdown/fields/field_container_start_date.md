# Date de mise en contenant

## field-container-start-date

{{field-start-date}}

#### label

- fr: Date de mise en contenant
- en: Container filling date
- es: Fecha de llenado del contenedor

#### question

- fr: Quelle est la date de mise en contenant?
- en: When did the filling take place?
- es: ¿Cuándo se realizó el llenado?
