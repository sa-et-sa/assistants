# Champ de pression par défaut

## field-pressure-default

### pressure

- id: pressure
- fieldType: decimal
- modifier: forCompute
- keyboardType: pressure

#### label

- fr: Pression
- en: Pressure
- es: Presión

#### question

- fr: Quelle est la pression à convertir?
- en: What is the pressure to convert?
- es: ¿Cuál es la presión a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
