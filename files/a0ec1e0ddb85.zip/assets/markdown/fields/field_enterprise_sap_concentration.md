# Champ de récolte de sève de l'entreprise

## field-enterprise-sap-concentration

### field_enterprise_sap_concentration

- id: field_enterprise_sap_concentration
- fieldType: yesno

#### label

- fr: Concentration de la sève
- en: Sap concentration
- es: Concentración de savia

#### question

- fr: Est-ce que l'entreprise concentre la sève ?
- en: Does the company concentrate sap?
- es: ¿La empresa concentra savia?

#### justification

- fr: Si oui, nous ajouterons le module de concentration de sève à votre compte.
- en: If yes, we will add the sap concentration module to your account.
- es: Si es así, agregaremos el módulo de concentración de savia a su cuenta.
