# Champ de masse par défaut

## field-volume-default

### volume

- id: volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### label

- fr: Volume
- en: Volume
- es: Volumen

#### question

- fr: Quel est le volume à convertir?
- en: What is the volume to convert?
- es: ¿Cuál es le volumen a convertir?

#### justification

{{justification-converter}}

#### answer

{{answer-number-default-precision}}
