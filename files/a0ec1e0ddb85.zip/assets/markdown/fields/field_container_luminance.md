# Champ de luminance du sirop

## field-container-luminance

### field_container_luminance

- id: field_container_luminance
- fieldType: integer
- keyboardType: luminance
- modifier: forCompute
- chartTypes: luminance

#### label

- fr: Luminance
- en: Luminance
- es: Luminancia

#### question

- fr: Quelle est la luminance du sirop ?
- en: What is the luminance of the syrup?
- es: ¿Cuál es la luminancia del jarabe?

#### justification

- fr: La luminance est une mesure de la clarté du sirop. Elle est importante pour déterminer la qualité et le prix du sirop.
- en: Luminance is a measure of the clarity of the syrup. It is important to determine the quality and price of the syrup.
- es: La luminancia es una medida de la claridad del jarabe. Es importante para determinar la calidad y el precio del jarabe.

#### answer

- answerType: number
  
##### numberValidation

- min: 0
- max: 100
