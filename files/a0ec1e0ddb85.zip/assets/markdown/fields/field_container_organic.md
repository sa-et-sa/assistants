# Champ de prime biologique

## field-container-organic

{{field-organic-certification}}

#### label

- fr: Prime biologique
- en: Organic premium
- es: Prima orgánica

#### question

- fr: Voulez-vous ajouter une prime biologique au prix du sirop ?
- en: Do you want to add an organic premium to the syrup price?
- es: ¿Desea agregar una prima orgánica al precio del jarabe?

#### justification

- fr: Il s'agit de la prime des PPAQ ajoutée au prix du sirop si celui-ci est biologique.
- en: This is the PPAQ premium added to the price of the syrup if it is organic.
- es: Esta es la prima de la PPAQ agregada al precio del jarabe si es orgánico.
