# Champ de dernière connexion de l'appareil Bluetooth

## field-ble-device-last-seen

### field_ble_device_last_seen

- id: field_ble_device_last_seen
- fieldType: integer

#### question

- fr: Dernière connexion (en secondes)
- en: Last seen (in seconds)
- es: Última conexión (en segundos)
