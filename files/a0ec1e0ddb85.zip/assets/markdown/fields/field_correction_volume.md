# Champ de volume de correction

## field-correction-volume

### field_correction_volume

- id: field_correction_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### question

- fr: Quel est le volume du sirop à corriger ?
- en: What is the volume of the syrup to correct?
- es: ¿Cuál es el volumen del jarabe a corregir?
