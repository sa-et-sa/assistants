# hamburger

## icon

- name: ☰

## name

- fr: L°Entailleur
- en: L°Entailleur
- es: L°Entailleur

## assistant-fields

### license

### user_welcome
