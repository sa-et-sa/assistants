# home

Cet assistant ne devrait pas exister. L'application devrait pouvoir utiliser l'assistant `user` pour afficher la page d'accueil.

## icon

- name: 🏠

## name

- fr: Accueil
- en: Home
- es: Inicio

## assistant-fields

Lorsque cette section est définie, elle permet de créer un champs d'assistant qui sera ajouté au début de la liste des champs de l'assistant.

Dans ce cas, le `FieldType` du field sera de type `assistant`.

Pour référencer un assistant, on doit utiliser un titre de niveau 3 (`###`) qui correspond à l'identifiant de l'assistant.

*IMPORTANT : Les assistants référencés dans cette section peuvent être déclarés à n'importe quel endroit dans le dossier `assistants`.*

### entreprise

Ici, on référence l'assistant `entreprise` et on déclare que le nombre maximum de résultats est de 1. Donc l'assistant `home` ne peut contenir qu'une seule entreprise.
`parameter-max-enterprise` est une variable déclarée dans le fichier [parameters.md](../../types/pa) qui contient le nombre maximum d'entreprises que l'utilisateur peut avoir.

- maxResults: 1

### refactoring de assistant-fields (non reconnu)

- [ ] Les `assistant-fields` devraient être déclarés dans la section `fields` de l'assistant.

## primary-tools

### calculators

### unit_converter

## secondary-tools

### bluetooth

## related-assistants

*Note: Cette section existe, car elle nous permet de pallier à une limitation de l'algorithme.*

On utilise la section `related-assistants` pour déclarer les assistants qui ont un lien avec l'assistant courant, mais qui ne sont pas des fields de celui-ci.

IMPORTANT : Les assistants référencés dans cette section doivent être déclarés dans le même dossier que l'assistant courant.

### hamburger

**refactoring de related-assistants (non reconnu)**

- [ ] Concept à revoir.
