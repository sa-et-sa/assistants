# license

## icon

- name: 👤

## name

- fr: Licences
- en: Licenses
- es: Licencias

## onboarding-fields

### license_list
