---
title: Licencias
ok-button: Atrás
---

***
[cupertino_icons](https://pub.dev/packages/cupertino_icons/license)

©️ Vladimir Kharlampidi  

***
[material_design_icons_flutter](https://pub.dev/packages/material_design_icons_flutter/license)

©️ 胖叔叔  

***
[equatable](https://pub.dev/packages/equatable/license)

©️ Felix Angelov  

***
[flutter_riverpod](https://pub.dev/packages/flutter_riverpod/license)

©️ Remi Rousselet  

***
[rxdart](https://pub.dev/packages/rxdart/license)

***
[hive](https://pub.dev/packages/hive/license)

[hive_flutter](https://pub.dev/packages/hive_flutter/license)

©️ Simon Leier  

***
[path_provider](https://pub.dev/packages/path_provider/license)

[shared_preferences](https://pub.dev/packages/shared_preferences/license)

[flutter_markdown](https://pub.dev/packages/flutter_markdown/license)

[file_selector](https://pub.dev/packages/file_selector/license)

[share_plus](https://pub.dev/packages/share_plus/license)

[url_launcher](https://pub.dev/packages/url_launcher/license)

©️ The Flutter Authors. All rights reserved.  

***
[async](https://pub.dev/packages/async/license)

[collection](https://pub.dev/packages/collection/license)

[path](https://pub.dev/packages/path/license)

[http](https://pub.dev/packages/http/license)

©️ the Dart project authors.

***
[uuid](https://pub.dev/packages/uuid/license)

©️ Yulian Kuncheff  

***
[spannable_grid](https://pub.dev/packages/spannable_grid/license)

©️ Evgeny Cherkasov  

***
[flutter_svg](https://pub.dev/packages/flutter_svg/license)

©️ Dan Field  

***
[archive](https://pub.dev/packages/archive/license)

©️ Brendan Duncan.  

***
[package_info_plus](https://pub.dev/packages/package_info_plus/license)

[device_info_plus](https://pub.dev/packages/device_info_plus/license)

©️ The Chromium Authors.  

***
[fl_chart](https://pub.dev/packages/fl_chart/license)

©️ Flutter 4 Fun  

***
[flutter_reactive_ble](https://pub.dev/packages/flutter_reactive_ble/license)

©️ Signify Holding.

***
[permission_handler](https://pub.dev/packages/permission_handler/license)

©️ Baseflow  

***
[app_settings](https://pub.dev/packages/app_settings/license)

©️ Daniel Spencer

***
[mobile_scanner](https://pub.dev/packages/mobile_scanner/license)

©️ Julian Steenbakker
