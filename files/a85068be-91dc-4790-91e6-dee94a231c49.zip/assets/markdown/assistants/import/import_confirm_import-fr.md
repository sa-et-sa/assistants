---
title: Sélection assistant
ok-button: "Confirmer"
cancel-button: "Annuler"
---

Confirmez vous l'importation de {count} résultats ?
