---
title: Import Assistant
ok-button: "Confirm"
cancel-button: "Cancel"
---

Do you confirm the import of {count} results?
