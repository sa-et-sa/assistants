# import

## icon

- name: 📂

## name

- fr: Importation des données
- en: Data import
- es: Importación de datos

## onboarding-fields

### import_select_file

### import_file_error

### import_confirm_import

### import_done

## output

- outputType: reference

### outputFormat

- fr: **{name}**
- en: **{name}**
- es: **{name}**
