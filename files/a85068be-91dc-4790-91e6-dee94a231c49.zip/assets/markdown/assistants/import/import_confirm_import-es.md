---
title: Asistente de Importación
ok-button: "Confirmar"
cancel-button: "Cancelar"
---

¿Confirmas la importación de {count} resultados?
