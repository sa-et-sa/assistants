---
title: Import Complete
ok-button: "Back"
---

The import is complete. You can now return to the homepage.
