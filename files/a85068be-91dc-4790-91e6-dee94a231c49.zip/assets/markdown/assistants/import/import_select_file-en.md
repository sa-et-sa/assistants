---
title: Import File
ok-button: "Open File"
---

You need to select a previously exported file. Click the button below to open the file.
