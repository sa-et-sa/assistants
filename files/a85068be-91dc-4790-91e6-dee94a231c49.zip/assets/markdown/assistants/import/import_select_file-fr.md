---
title: Fichier d'importation
ok-button: "Ouvrir le fichier"
---

Vous devez sélectionner un fichier précédemment exporté. Cliquez sur le bouton ci-dessous pour ouvrir le fichier.
