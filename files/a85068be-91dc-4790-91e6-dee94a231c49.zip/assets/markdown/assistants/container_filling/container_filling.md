# container_filling

## icon

- name: 🛢️

## name

- fr: Mise en contenant
- en: Container filling
- es: Llenado de contenedor

## related-assistants

### mise_en_contenant
