# mise_en_contenant

## icon

- name: 🛢️

## category

- type: inventory

## name

- fr: Mise en contenant
- en: Container filling
- es: Llenado de contenedores

## computeTitle

- fr: Prix du sirop
- en: Syrup price
- es: Precio del jarabe

## fields

### field_start_date

- id: field_start_date
- fieldType: dateTime

#### answer

- answerType: dateTime

#### label

- fr: Date de mise en contenant
- en: Container filling date
- es: Fecha de llenado del contenedor

#### question

- fr: Quelle est la date de mise en contenant?
- en: When did the filling take place?
- es: ¿Cuándo se realizó el llenado?

### field_container_id

- id: field_container_id
- fieldType: barcode

#### label

- fr: Numéro du contenant
- en: Container number
- es: Número del contenedor

#### question

- fr: Quel est le numéro du contenant ?
- en: What is the container number?
- es: ¿Cuál es el número del contenedor?

#### justification

- fr: Le numéro du contenant est important pour la traçabilité. De plus, il nous permettra de faire l'association avec le rapport de classement du sirop. Si le contenant possède un code-barres, vous pouvez le scanner. S'il n'en possède pas, vous pouvez le saisir manuellement à l'aide du bouton ⌨️.
- en: The container number is important for traceability. In addition, it will allow us to associate it with the syrup grading report. If the container has a barcode, you can scan it. If it does not have one, you can enter it manually using the ⌨️ button.
- es: El número del contenedor es importante para la trazabilidad. Además, nos permitirá asociarlo con el informe de clasificación del jarabe. Si el contenedor tiene un código de barras, puede escanearlo. Si no tiene uno, puede ingresarlo manualmente usando el botón ⌨️.

### field_container_volume

- id: field_container_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume
- chartTypes: productionValue, averagePrice

#### label

- fr: Volume de sirop
- en: Syrup volume
- es: Volumen de jarabe

#### question

- fr: Quel est le volume du sirop ?
- en: What is the syrup volume?
- es: ¿Cuál es el volumen del jarabe?

#### answer

- answerType: number

##### numberValidation

- precision: 2

### field_container_brix

- id: field_container_brix
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix
- chartTypes: brix

#### label

- fr: Degré Brix (˚B) à 20˚C
- en: Brix degree (˚B) at 20˚C
- es: Grado Brix (˚B) a 20˚C

#### question

- fr: Quelle est le Degré Brix (˚B) à 20˚C ?
- en: What is the Brix degree (˚B) at 20˚C?
- es: ¿Cuál es el Grado Brix (˚B) a 20˚C?

#### justification

- fr: Il est important de mesurer le degré brix à 20°C, notamment à l'aide d'un réfractomètre. De plus, le poids spécifique du sirop est calculé à l'aide d'une table de conversion mesurée à 20°C Référence: *Calcul du poids spécifique relatif (densité) d’une solution de sucre d’érable en fonction de sa concentration (°Brix) Par Gaston B. Allard ing., agr.*
- en: It is important to measure the Brix degree at 20°C, especially using a refractometer. In addition, the specific weight of the syrup is calculated using a conversion table measured at 20°C. Reference: *Calculation of the relative specific weight (density) of a maple sugar solution based on its concentration (°Brix) By Gaston B. Allard ing., agr.*
- es: Es importante medir el grado Brix a 20°C, especialmente utilizando un refractómetro. Además, el peso específico del jarabe se calcula utilizando una tabla de conversión medida a 20°C. Referencia: *Cálculo del peso específico relativo (densidad) de una solución de azúcar de arce en función de su concentración (°Brix) Por Gaston B. Allard ing., agr.*

#### answer

- answerType: number
  
##### numberValidation

- min: 66
- max: 70
- precision: 1
- preFilledValue: 66.5

### field_container_luminance

- id: field_container_luminance
- fieldType: integer
- keyboardType: luminance
- modifier: forCompute
- chartTypes: luminance

#### label

- fr: Luminance
- en: Luminance
- es: Luminancia

#### question

- fr: Quelle est la luminance du sirop ?
- en: What is the luminance of the syrup?
- es: ¿Cuál es la luminancia del jarabe?

#### justification

- fr: La luminance est une mesure de la clarté du sirop. Elle est importante pour déterminer la qualité et le prix du sirop.
- en: Luminance is a measure of the clarity of the syrup. It is important to determine the quality and price of the syrup.
- es: La luminancia es una medida de la claridad del jarabe. Es importante para determinar la calidad y el precio del jarabe.

#### answer

- answerType: number
  
##### numberValidation

- min: 0
- max: 100

### field_container_ppaq_defect

- id: field_container_ppaq_defect
- fieldType: choices
- choiceSource: defaut_saveur
- modifier: forCompute

#### label

- fr: Défaut de saveur
- en: Flavor defect
- es: Defecto de sabor

#### question

- fr: Avez-vous détecté un défaut de saveur ?
- en: Did you detect a flavor defect?
- es: ¿Detectó un defecto de sabor?

#### justification

- fr: Les défauts de saveur peuvent être causés par une mauvaise manipulation du sirop ou par une contamination. Ils peuvent affecter la qualité et le prix du sirop.
- en: Flavor defects can be caused by improper syrup handling or contamination. They can affect the quality and price of the syrup.
- es: Los defectos de sabor pueden ser causados por una manipulación incorrecta del jarabe o por contaminación. Pueden afectar la calidad y el precio del jarabe.

### field_organic_certification

- id: field_organic_certification
- fieldType: yesno
- modifier: forCompute

#### label

- fr: Prime biologique
- en: Organic premium
- es: Prima orgánica

#### question

- fr: Voulez-vous ajouter une prime biologique au prix du sirop ?
- en: Do you want to add an organic premium to the syrup price?
- es: ¿Desea agregar una prima orgánica al precio del jarabe?

#### justification

- fr: Il s'agit de la prime des PPAQ ajoutée au prix du sirop si celui-ci est biologique.
- en: This is the PPAQ premium added to the price of the syrup if it is organic.
- es: Esta es la prima de la PPAQ agregada al precio del jarabe si es orgánico.

## secondary-tools

### delete

## output

- outputType: reference

### outputFormat

- fr: **Numéro: {field_container_id}**{_newline} {field_container_volume} à {field_container_brix}{_newline}Luminance: {field_container_luminance}{_newline}Défaut de saveur: {field_container_ppaq_defect}
- en: **Number: {field_container_id}**{_newline} {field_container_volume} at {field_container_brix}{_newline}Luminance: {field_container_luminance}{_newline}Flavor defect: {field_container_ppaq_defect}
- es: **Número: {field_container_id}**{_newline} {field_container_volume} a {field_container_brix}{_newline}Luminancia: {field_container_luminance}{_newline}Defecto de sabor: {field_container_ppaq_defect}

### resultsFormat

- fr: {_title}Nombre de mises en contenant: {_count}
- en: {_title}Number of fillings: {_count}
- es: {_title}Número de llenado: {_count}

### noResultFormat

- fr: {_title}Aucune mise en contenant pour la période.
- en: {_title}No fillings for the period.
- es: {_title}No hay llenados durante el período.
