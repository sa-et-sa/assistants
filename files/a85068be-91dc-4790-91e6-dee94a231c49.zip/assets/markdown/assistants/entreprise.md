
# entreprise

## icon

- name: 🏢

## category

- type: inventory

## name

- fr: Entreprise
- en: Company
- es: Empresa
  
## fields

### field_enterprise_name

- id: field_enterprise_name
- fieldType: text

#### answer

- answerType: string

#### label

- fr: Nom de l'entreprise
- en: Company name
- es: Nombre de la empresa

#### question

- fr: Quel est le nom de votre entreprise ?
- en: What is the name of your company?
- es: ¿Cuál es el nombre de su empresa?

#### justification

- fr: Nous vous demandons cette information afin de personnaliser votre expérience. Nous ne partagerons pas cette information sans vous en informer.
- en: We ask for this information to personalize your experience. We will not share this information without informing you.
- es: Solicitamos esta información para personalizar su experiencia. No compartiremos esta información sin informarle.

### field_organic_certification

- id: field_organic_certification
- fieldType: yesno
- modifier: forCompute

#### label

- fr: Certification biologique
- en: Organic certification
- es: Certificación orgánica

#### question

- fr: Est-ce que votre entreprise est certifiée biologique ?
- en: Is your company certified organic?
- es: ¿Su empresa está certificada como orgánica?

#### justification

- fr: Cette information nous permet de pré-remplir les champs de certification biologique.
- en: This information allows us to pre-fill the organic certification fields.
- es: Esta información nos permite rellenar automáticamente los campos de certificación orgánica.

### field_enterprise_container_filling

- id: field_enterprise_container_filling
- fieldType: yesno

#### label

- fr: Mise en contenant
- en: Container filling
- es: Llenado de contenedores

#### question

- fr: Est-ce que l'entreprise effectue la mise en contenant ?
- en: Does the company perform container filling?
- es: ¿La empresa realiza el llenado de contenedores ?

#### justification

- fr: Si oui, nous ajouterons le module de récolte de sève à votre compte.
- en: If yes, we will add the sap harvesting module to your account.
- es: Si es así, agregaremos el módulo de cosecha de savia a su cuenta.

## secondary-tools

### import

## output

- outputType: reference

### outputFormat

- fr: **{field_enterprise_name}**{_newline}Certification biologique : {field_organic_certification}
- en: **{field_enterprise_name}**{_newline}Organic certification: {field_organic_certification}
- es: **{field_enterprise_name}**{_newline}Certificación orgánica: {field_organic_certification}

### noResultFormat

- fr: {_title}Vous devez d'abord saisir vos informations d'entreprise afin de continuer. Cliquez ici pour le faire !
- en: {_title}You must first enter your company information in order to continue. Click here to do so!
- es: {_title}Primero debe ingresar la información de su empresa para continuar. ¡Haga clic aquí para hacerlo!
