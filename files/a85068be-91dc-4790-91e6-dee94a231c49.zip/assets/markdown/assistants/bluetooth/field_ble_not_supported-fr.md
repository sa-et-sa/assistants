---
title: Bluetooth non pris en charge
ok-button: "Retour"
---

Cet appareil ne prend pas en charge le Bluetooth. Vous ne pouvez pas afficher vos appareils Bluetooth ici.
