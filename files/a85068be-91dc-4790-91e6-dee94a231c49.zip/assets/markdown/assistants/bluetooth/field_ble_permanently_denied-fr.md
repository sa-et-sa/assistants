---
title: Permission Bluetooth refusée de manière permanente
ok-button: "Rediriger vers les paramètres"
---

Vous avez refusé la permission d'accéder au Bluetooth. Nous ne pourrons pas afficher vos appareils.

Nous allons vous rediriger vers les paramètres. Vous devrez nous donner les permissions d'accéder au Bluetooth ou aux appareils à proximité.
