---
title: Bluetooth Permission Not Granted
ok-button: "Request Permission"
---

We will ask for permission to access Bluetooth. If you refuse, we will not be able to display your devices.
