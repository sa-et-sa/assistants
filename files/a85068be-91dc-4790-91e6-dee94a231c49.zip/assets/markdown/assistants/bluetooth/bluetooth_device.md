# bluetooth_device

- version:  0.0.1

## icon

- name: 🕹️

## name

- fr: Appareil Bluetooth
- en: Bluetooth Device
- es: Dispositivo Bluetooth

## fields

### field_ble_device_name

- id: field_ble_device_name
- fieldType: text

#### question

- fr: Nom
- en: Name
- es: Nombre

### field_ble_device_rssi

- id: field_ble_device_rssi
- fieldType: integer
  
#### question

- fr: RSSI
- en: RSSI
- es: RSSI

### field_ble_device_last_seen

- id: field_ble_device_last_seen
- fieldType: integer

#### question

- fr: Dernière connexion (en secondes)
- en: Last seen (in seconds)
- es: Última conexión (en segundos)

## output

- outputType: reference

### outputFormat

- fr: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Dernière connexion: {field_ble_device_last_seen}
- en: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Last seen: {field_ble_device_last_seen}
- es: **{field_ble_device_name}**{_newline}RSSI: {field_ble_device_rssi}{_newline}Última conexión: {field_ble_device_last_seen}
