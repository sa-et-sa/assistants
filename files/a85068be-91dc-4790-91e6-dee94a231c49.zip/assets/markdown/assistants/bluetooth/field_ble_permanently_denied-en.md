---
title: Bluetooth Permission Permanently Denied
ok-button: "Redirect to Settings"
---

You have permanently denied permission to access Bluetooth. We will not be able to display your devices.

We will redirect you to the settings. You will need to grant us permissions to access Bluetooth or nearby devices.
