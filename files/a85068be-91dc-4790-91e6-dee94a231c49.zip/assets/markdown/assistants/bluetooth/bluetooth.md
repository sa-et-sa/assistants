# bluetooth

- version:  0.0.1

## icon

- name: 📶

## name

- fr: Bluetooth
- en: Bluetooth
- es: Bluetooth

## fields

### field_ble_enabled

- id: field_ble_enabled
- fieldType: message

#### question

- fr: Recherche d'appareils Bluetooth...
- en: Searching for Bluetooth devices...
- es: Buscando dispositivos Bluetooth...

## onboarding-fields

### field_ble_not_supported

### field_ble_not_granted

### field_ble_permanently_denied

## related-assistants

### bluetooth_device
