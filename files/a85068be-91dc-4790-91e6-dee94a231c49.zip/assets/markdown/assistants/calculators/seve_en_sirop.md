# seve_en_sirop

## icon

- name: ⚗️

## category

- type: calculator

## name

- fr: Concentration eau en sirop
- en: Sap concentration in syrup
- es: Concentración de savia en jarabe

## fields

### field_water_brix_source

- id: field_water_brix_source
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

- fr: Degré Brix (˚B) à 20˚C
- en: Brix degree (˚B) at 20˚C
- es: Grado Brix (˚B) a 20˚C

#### question

- fr: Quelle est le Degré Brix (˚B) à 20˚C ?
- en: What is the Brix degree (˚B) at 20˚C?
- es: ¿Cuál es el Grado Brix (˚B) a 20˚C?

#### justification

- fr: Il s'agit de la concentration en sucre de l'eau d'érable avant la concentration. Les valeurs admissibles sont de 0.1 à 66. **N'oubliez pas de faire l'ajustement à la température si nécessaire.**
- en: This is the sugar concentration of the maple water before concentration. The acceptable values are from 0.1 to 66. **Don't forget to make the temperature adjustment if necessary.**
- es: Esta es la concentración de azúcar del agua de arce antes de la concentración. Los valores aceptables son de 0.1 a 66. **No olvide hacer el ajuste de temperatura si es necesario.**.

#### answer

- answerType: number
  
##### numberValidation

- min: 0.1
- max: 66
- precision: 1

### field_water_volume

- id: field_water_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### label

- fr: Quantité d'eau
- en: Water quantity
- es: Cantidad de agua

#### question

- fr: Quel est le volume d'eau d'érable?
- en: What is the volume of maple water?
- es: ¿Cuál es el volumen de agua de arce?

#### justification

- fr: Le volume d'eau d'érable nous permettra d'estimer la quantité résultante suite à la concentration.
- en: The volume of maple water will allow us to estimate the resulting quantity following the concentration.
- es: El volumen de agua de arce nos permitirá estimar la cantidad resultante después de la concentración.

### field_water_brix_target

- id: field_water_brix_target
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

- fr: Degré Brix (˚B) à 20˚C désiré
- en: Desired Brix degree (˚B) at 20˚C
- es: Grado Brix (˚B) a 20˚C deseado

#### question

- fr: Quelle est le Degré Brix (˚B) à 20˚C désiré ?
- en: What is the desired Brix degree (˚B) at 20˚C?
- es: ¿Cuál es el Grado Brix (˚B) a 20˚C deseado?

#### justification

- fr: Il s'agit du degré Brix souhaité de l'eau d'érable que vous souhaitez obtenir. Les valeurs admissibles sont de 2 à 70. **Si vous saisissiez une valeur inférieure à celle de la concentration de l'eau d'érable, le calcul ne sera pas valide.**
- en: This is the desired Brix degree of the maple water you want to obtain. The acceptable values are from 2 to 70. **If you enter a value lower than the concentration of the maple water, the calculation will not be valid.**
- es: Este es el grado Brix deseado del agua de arce que desea obtener. Los valores aceptables son de 2 a 70. **Si ingresa un valor inferior a la concentración del agua de arce, el cálculo no será válido.**

#### answer

- answerType: number
  
##### numberValidation

- min: 2
- max: 70
- precision: 1

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer la quantité de sirop ou de concentré que donnera une quantité d'eau d'érable ou de concentré.
- en: {_title}Calculate the quantity of syrup or concentrate that will result from a quantity of maple water or concentrate.
- es: {_title}Calcular la cantidad de jarabe o concentrado que resultará de una cantidad de agua de arce o concentrado.
