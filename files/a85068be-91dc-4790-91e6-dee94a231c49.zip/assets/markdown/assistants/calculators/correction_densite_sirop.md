# correction_densite_sirop

## icon

- name: 🚰

## category

- type: calculator

## name

- fr: Correction de la densité sirop
- en: Syrup density correction
- es: Corrección de la densidad del jarabe

## fields

### field_correction_brix_source

- id: field_correction_brix_source
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### question

- fr: Quelle est la concentration en sucre?
- en: What is the sugar concentration?
- es: ¿Cuál es la concentración de azúcar?

#### justification

- fr: Cette concentration doit être supérieur à la concentration désirée. Les plages de valeurs admissibles sont de 66 à 70, car il n'est pas recommandé de corriger un sirop dont la concentration est inférieure à 66.
- en: This concentration must be higher than the desired concentration. The acceptable value ranges are from 66 to 70, as it is not recommended to correct a syrup with a concentration lower than 66.
- es: Esta concentración debe ser mayor que la concentración deseada. Los rangos de valores aceptables son de 66 a 70, ya que no se recomienda corregir un jarabe con una concentración inferior a 66..

#### answer

- answerType: number
  
##### numberValidation

- min: 66
- max: 70
- precision: 1
- preFilledValue: 66.5

### field_correction_volume

- id: field_correction_volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### question

- fr: Quel est le volume du sirop à corriger ?
- en: What is the volume of the syrup to correct?
- es: ¿Cuál es el volumen del jarabe a corregir?

### field_correction_brix_target

- id: field_correction_brix_target
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### question

- fr: Quelle est la concentration en sucre désirée ?
- en: What is the desired sugar concentration?
- es: ¿Cuál es la concentración de azúcar deseada?

#### justification

- fr: Cette concentration doit être inférieure à la concentration du sirop à corriger. Les plages de valeurs admissibles sont de 66 à 70, car il n'est pas recommandé de soumettre un sirop qui n'est pas dans cette plage de valeurs. **Si vous obtenez un nombre négatif**, cela signifie que vous devez retirer de l'eau du sirop plutôt que d'en ajouter.
- en: This concentration must be lower than the concentration of the syrup to be corrected. The acceptable value ranges are from 66 to 70, as it is not recommended to submit a syrup that is not in this value range. If you get a negative number, it means you need to remove water from the syrup rather than add it.
- es: Esta concentración debe ser menor que la concentración del jarabe a corregir. Los rangos de valores aceptables son de 66 a 70, ya que no se recomienda someter un jarabe que no esté en este rango de valores. Si obtiene un número negativo, significa que debe retirar agua del jarabe en lugar de agregarla.

#### answer

- answerType: number
  
##### numberValidation

- min: 66
- max: 70
- precision: 1
- preFilledValue: 66.5

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer l'eau à ajouter pour diminuer la densité du sirop.
- en: {_title}Calculate the water to add to decrease the syrup density.
- es: {_title}Calcular el agua a añadir para disminuir la densidad del jarabe.
