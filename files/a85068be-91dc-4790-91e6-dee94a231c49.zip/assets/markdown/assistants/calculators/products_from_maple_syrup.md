# products_from_maple_syrup

## icon

- name: 🍁

## category

- type: calculator

## name

- fr: Quantité de sirop pour produits
- en: Quantity of syrup for products
- es: Cantidad de jarabe para productos

## fields

### maple_product

- id: maple_product
- fieldType: choices
- choiceSource: maple_product
- modifier: forCompute

#### question

- fr: Que voulez vous produire ?
- en: What do you want to produce ?
- es: ¿Qué quieres producir ?

### quantity

- id: quantity
- fieldType: integer
- modifier: forCompute

#### question

- fr: Quelle est la quantité que vous voulez produire ?
- en: What is the quantity you want to produce ?
- es: ¿Cuál es la cantidad que quieres producir ?

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Calculer la quantité de sirop requise pour faire des produits
- en: **{name}**{_newline}Calculate the quantity of syrup required to make products
- es: **{name}**{_newline}Calcular la cantidad de jarabe necesaria para hacer productos
