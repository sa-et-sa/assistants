# poids_specifique

## icon

- name: ⚖️

## category

- type: calculator

## name

- fr: Poids spécifique
- en: Specific weight
- es: Peso específico

## fields

### field_weight_brix

- id: field_weight_brix
- fieldType: decimal
- modifier: forCompute
- keyboardType: brix

#### label

- fr: Degré Brix (˚B) à 20˚C
- en: Brix degree (˚B) at 20˚C
- es: Grado Brix (˚B) a 20˚C

#### question

- fr: Quelle est le Degré Brix (˚B) à 20˚C ?
- en: What is the Brix degree (˚B) at 20˚C?
- es: ¿Cuál es el Grado Brix (˚B) a 20˚C?

#### justification

- fr: Il est important de mesurer le degré brix à 20°C, notamment à l'aide d'un réfractomètre. De plus, le poids spécifique du sirop est calculé à l'aide d'une table de conversion mesurée à 20°C Référence: *Calcul du poids spécifique relatif (densité) d’une solution de sucre d’érable en fonction de sa concentration (°Brix) Par Gaston B. Allard ing., agr.*
- en: It is important to measure the Brix degree at 20°C, especially using a refractometer. In addition, the specific weight of the syrup is calculated using a conversion table measured at 20°C. Reference: *Calculation of the relative specific weight (density) of a maple sugar solution based on its concentration (°Brix) By Gaston B. Allard ing., agr.*
- es: Es importante medir el grado Brix a 20°C, especialmente utilizando un refractómetro. Además, el peso específico del jarabe se calcula utilizando una tabla de conversión medida a 20°C. Referencia: *Cálculo del peso específico relativo (densidad) de una solución de azúcar de arce en función de su concentración (°Brix) Por Gaston B. Allard ing., agr.*

#### answer

- answerType: number
  
##### numberValidation

- min: 0.1
- max: 70
- precision: 1

## output

- outputType: none

### noResultFormat

- fr: {_title}Calculer le poids spécifique d'une solution de sucre.
- en: {_title}Calculate the specific weight of a sugar solution.
- es: {_title}Calcular el peso específico de una solución de azúcar.
