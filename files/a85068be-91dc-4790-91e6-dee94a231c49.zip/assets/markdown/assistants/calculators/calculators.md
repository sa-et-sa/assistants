# calculators

## icon

- name: 🧮

## category

- type: calculator

## name

- fr: Calculateurs
- en: Calculators
- es: Calculadoras

## assistant-fields

### prix_sirop_ppaq

### seve_en_sirop

### correction_densite_sirop

### poids_specifique

### maple_syrup_to_products

### products_from_maple_syrup

## output

- outputType: none

### outputFormat

- fr: aucun
- en: none
- es: ninguno
