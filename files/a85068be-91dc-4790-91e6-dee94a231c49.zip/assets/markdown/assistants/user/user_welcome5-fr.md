---
title: Registre de production
ok-button: D'accord
---

🛢️ Saisissez vos informations de production:

- Date
- Numéro du contenant (saisissable avec le scanner de code-barre intégré)
- Volume
- Degré Brix
- Luminance
- Défaut de saveur

À la réception de votre rapport de classement, notre application vous permettra de comparer les données de votre rapport avec celles de votre registre de production. Et les anomalies seront mises en évidence automatiquement. ❌ ✅
