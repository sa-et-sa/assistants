---
title: Interface utilisateur
ok-button: D'accord
---

Nous avons conçu l'interface utilisateur de l'application pour qu'elle soit la plus intuitive possible.

Pour cette raison, nous recueillons vos données à l'aide d'un assistant de conversation. Rien de plus simple, c'est une interface connue de tous. 💬

Nous supportons également plusieurs langues, dont le français, l'anglais et l'espagnol. Ainsi que l'affiche de polices de caractères plus grandes pour les utilisateurs ayant des difficultés de vision. 🤓

Et pour la distinguer des autres applications, nous lui avons donné un petit look *cabane à sucre* 🍁 que vous apprécierez, nous en sommes sûr.
