---
title: Conversión de unidades
ok-button: De acuerdo
---

🔍 Busca el botón 💱 en la barra de botones de la aplicación para realizar rápidamente una conversión de unidades.

Además, al ingresar tu registro de producción, encontrarás este botón 💱 en el teclado.

De esta manera, puedes ingresar la cantidad de jarabe en la unidad de volumen de tu elección.
