---
title: User Interface
ok-button: Agree
---

We designed the application's user interface to be as intuitive as possible.

For this reason, we collect your data using a conversation assistant. Nothing could be simpler, it's an interface familiar to everyone. 💬

We also support multiple languages, including French, English, and Spanish. As well as displaying larger fonts for users with vision difficulties. 🤓

And to distinguish it from other applications, we gave it a little *sugar shack* look 🍁 that we are sure you will appreciate.
