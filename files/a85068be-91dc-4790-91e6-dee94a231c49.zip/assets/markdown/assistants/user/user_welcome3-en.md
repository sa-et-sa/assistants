---
title: Maple Syrup Calculations
ok-button: Agree
---

🔍 Look for the 🧮 button in the application's button bar to access various maple syrup calculations, including:

- 💲 Bulk syrup price 2025
- ⚗️ Sap to syrup concentration
- 🚰 Syrup density correction
- 🍁 Amount of syrup to make products
