# user_welcome

## icon

- name: 👋

## category

- type: other

## name

- fr: Mots de bienvenue
- en: Welcome words
- es: Palabras de bienvenida

## onboarding-fields

### user_welcome7

### user_welcome6

### user_welcome5

### user_welcome4

### user_welcome3

### user_welcome2

### user_welcome1
