---
title: Conversion d'unités
ok-button: D'accord
---

🔍 Recherchez le bouton 💱 dans la barre de boutons de l'application afin d'effectuer rapidement une conversion d'unité.

De plus, lors de la saisie de votre registre de production, vous retrouverez ce bouton 💱 dans le clavier.

Ainsi vous pourrez saisir votre quantité de sirop dans l'unité de volume de votre choix.
