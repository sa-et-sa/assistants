---
title: ¡Bienvenido a L'Entailleur!
ok-button: De acuerdo
---

¡Hola entusiastas del arce! 👋

Para agradecerte por tu interés, he decidido ofrecerte algunas funciones gratis que desarrollé con mi amigo JM. 🎁

Las siguientes pantallas presentarán rápidamente las principales características.

Espero que las disfrutes,

Karl 😊
