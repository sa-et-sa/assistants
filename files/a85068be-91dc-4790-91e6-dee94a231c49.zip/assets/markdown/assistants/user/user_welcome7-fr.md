---
title: Mises à jour
ok-button: D'accord
---

Au cours des prochaines semaines, nous mettrons régulièrement à jour notre application.

À chaque mise à jour, vous serez informé des nouveautés. 📢

Pour ne rien manquer, vous pourrez toujours accéder à ces informations à partir du menu principal ☰.

Ainsi que d'autres informations à propos de l'application et de Samares et Sablier (Sa&Sa), l'entreprise derrière tout ça. ⏳
