---
title: Informations d'entreprise
ok-button: D'accord
---

Remplissez vos informations d'entreprise 🏢 afin d'accéder au registre de production.

Notre application a d'abord été conçue pour faciliter la gestion de petites entreprises acéricoles. Pour cette raison, notre version gratuite limite l'accès à nos fonctionnalités avancées pour les plus grandes entreprises.

🔐 Les informations que vous saisissez vous appartiennent, demeurent sur votre téléphone, et ne sont partagées avec personne.

Si vous effectuez la mise en contenant, vous pouvez saisir gratuitement vos 50 premiers barils ! 🎉
