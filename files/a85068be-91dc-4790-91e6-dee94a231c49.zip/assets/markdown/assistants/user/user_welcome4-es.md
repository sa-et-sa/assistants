---
title: Información de la empresa
ok-button: De acuerdo
---

Completa la información de tu empresa 🏢 para acceder al registro de producción.

Nuestra aplicación fue diseñada inicialmente para facilitar la gestión de pequeñas empresas de jarabe de arce. Por esta razón, nuestra versión gratuita limita el acceso a nuestras funciones avanzadas para empresas más grandes.

🔐 La información que ingresas te pertenece, permanece en tu teléfono y no se comparte con nadie.

Si estás embotellando, ¡puedes ingresar tus primeros 50 barriles gratis! 🎉
