# Utilisateur anonyme

Cet assistant représente l'utilisateur anonyme. Cet utilisateur est celui utilisé par la version gratuite de l'application.

Un utilisateur payant et authentifié devrait probablement avoir son propre assistant qui remplace celui-ci.

## icon

- name: 👤

## category

- type: inventory

## name

- fr: Utilisateur
- en: User
- es: Usuario

## fields

Ces déclarations de champs correspondent à l'ancienne façon de déclarer les champs. Elles devront être remplacées selon la méthode discutées dans [root.md](../root.md).

Les fields doivent être définis dans un fichier à part et placés dans le dossier `fields`, au même niveau que le dossiers `assistants`.

**refactoring de fields (non reconnu)**

- [ ] Les fields devraient fonctionner sous le même principe que les `assistant-fields`. Autrement dit, seulement déclarer à l'aide d'un fichier placé dans le dossier `fields` et les importer dans les assistants qui en ont besoin.
- [ ] Certains ajustement des fields devraient pouvoir exister afin de les personnaliser pour un assistant. Notamment les sections `questions`et `justifications`.
- [ ] Les `assistant-fields` devraient également être déclarés dans cette section. On pourrait utiliser le préfix `assistant-` pour les distinguer des fields. Cela permettrait également de pouvoir insérer des fields d'assistant à travers les fields, ce qui pourrait être important pour l'ordre d'affichage des fields.

### id

Ici le champ id est déclaré comme constant, ce qui fait en sorte que ce champ ne peut pas être modifié et qu'il n'est pas affiché dans les conversations.

- id: id
- fieldType: text
- modifier: constant

#### label

- fr: Courriel
- en: Email
- es: Correo electrónico

#### question

- fr: Quel est votre courriel ?
- en: What is your email?
- es: ¿Cuál es su correo electrónico?

#### answer

- answerType: string

##### values

- value: <allo@sa-et-sa.com>

## assistant-fields

### refactoring de assistant-fields (non reconnu)

- [ ] On devrait déclarer un assistant `entreprise` (maxResult = 1). Il s'agirait de la seule entreprise permise pour l'utilisateur anonyme.

## onboarding-fields

Lorsque cette section est définie, elle permet de créer un champs d'onboarding qui sera ajouté au début de la liste des champs de l'assistant, après les champs d'assistant.

Dans ce cas, le `FieldType` du field sera de type `onboarding`.

Pour référencer un assistant, on doit utiliser un titre de niveau 3 (`###`) qui correspond à l'identifiant de l'assistant.

Contrairement aux `assistant-fields`, l'id est soumis aux contraintes suivantes:

1. L'id ne doit pas contenir de suffixe de langue (ex: `-fr`). Tous les fichiers ayant les mêmes id, mais avec des suffixes de langue différents, seront associés.
2. Le fichier représenté par l'id doit être dans le même dossier que le fichier qui le référence.

### user_welcome7

### user_welcome6

### user_welcome5

### user_welcome4

### user_welcome3

### user_welcome2

### user_welcome1

### refactoring de onboarding-fields (non reconnu)

- [ ] Au lieu d'être insérés dans les `fields`de l'assistant, les `onboarding-fields` devraient être complètement à part et être affiché en introduction de l'assistant la première fois que celui-ci est appelé.
- [ ] Les `onboarding-fields` devraient pouvoir être déclaré dans l'ordre d'apparition dans la conversation. Pour le moment, ils sont déclarés dans l'ordre inverse.
