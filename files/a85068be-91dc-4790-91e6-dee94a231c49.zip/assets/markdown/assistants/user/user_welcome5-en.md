---
title: Production Log
ok-button: Agree
---

🛢️ Enter your production information:

- Date
- Container number (scannable with a barcode scanner)
- Volume
- Brix degree
- Luminance
- Flavor defect

Upon receiving your grading report, our application will allow you to compare the data from your report with those in your production log. And anomalies will be automatically highlighted. ❌ ✅
