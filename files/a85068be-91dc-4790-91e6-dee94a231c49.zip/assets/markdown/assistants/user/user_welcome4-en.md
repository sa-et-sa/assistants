---
title: Company Information
ok-button: Agree
---

Fill in your company information 🏢 to access the production log.

Our application was initially designed to facilitate the management of small maple syrup businesses. For this reason, our free version limits access to our advanced features for larger companies.

🔐 The information you enter belongs to you, remains on your phone, and is not shared with anyone.

If you are bottling, you can enter your first 50 barrels for free! 🎉
