---
title: Welcome to L'Entailleur!
ok-button: Agree
---

Hello maple enthusiasts! 👋

To thank you for your interest, I have decided to offer you some features for free that I developed with my friend JM. 🎁

The following screens will quickly introduce the main features.

I hope you enjoy them,

Karl 😊
