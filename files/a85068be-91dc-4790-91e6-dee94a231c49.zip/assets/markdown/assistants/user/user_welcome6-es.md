---
title: Interfaz de usuario
ok-button: De acuerdo
---

Diseñamos la interfaz de usuario de la aplicación para que sea lo más intuitiva posible.

Por esta razón, recopilamos tus datos utilizando un asistente de conversación. Nada más simple, es una interfaz conocida por todos. 💬

También soportamos varios idiomas, incluyendo francés, inglés y español. Así como la visualización de fuentes más grandes para usuarios con dificultades de visión. 🤓

Y para distinguirla de otras aplicaciones, le dimos un pequeño aspecto de *cabaña de azúcar* 🍁 que estamos seguros de que apreciarás.
