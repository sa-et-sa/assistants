---
title: Actualizaciones
ok-button: De acuerdo
---

Durante las próximas semanas, actualizaremos regularmente nuestra aplicación.

Con cada actualización, se te informará sobre las nuevas características. 📢

Para asegurarte de no perderte nada, siempre puedes acceder a esta información desde el menú principal ☰.

Así como otra información sobre la aplicación y Samares et Sablier (Sa&Sa), la empresa detrás de todo esto. ⏳
