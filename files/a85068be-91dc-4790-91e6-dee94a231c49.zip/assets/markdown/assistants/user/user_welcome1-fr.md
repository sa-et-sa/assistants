---
title: Bienvenue dans L˚Entailleur !
ok-button: D'accord
---

Bonjour aux passionnés de l'érable ! 👋

Pour vous remercier de votre intérêt, j'ai décidé de vous offrir gratuitement certaines fonctionnalités de celles-ci que j'ai développé avec mon ami JM. 🎁

Les écrans suivants vont présenteront rapidement les principales fonctionnalités.

J'espère que vous les apprécierez,

Karl 😊
