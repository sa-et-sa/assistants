---
title: Updates
ok-button: Agree
---

Over the next few weeks, we will regularly update our application.

With each update, you will be informed of the new features. 📢

To make sure you don't miss anything, you can always access this information from the main menu ☰.

As well as other information about the application and Samares et Sablier (Sa&Sa), the company behind it all. ⏳
