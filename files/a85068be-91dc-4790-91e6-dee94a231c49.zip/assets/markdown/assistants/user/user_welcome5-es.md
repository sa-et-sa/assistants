---
title: Registro de producción
ok-button: De acuerdo
---

🛢️ Ingresa tu información de producción:

- Fecha
- Número de contenedor (escaneable con un escáner de código de barras)
- Volumen
- Grado Brix
- Luminancia
- Defecto de sabor

Al recibir tu informe de clasificación, nuestra aplicación te permitirá comparar los datos de tu informe con los de tu registro de producción. Y las anomalías se destacarán automáticamente. ❌ ✅
