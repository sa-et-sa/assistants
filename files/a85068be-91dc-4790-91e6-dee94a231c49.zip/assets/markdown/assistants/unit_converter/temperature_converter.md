# temperature_converter

## icon

- name: 🌡️

## category

- type: calculator

## name

- fr: Température
- en: Temperature
- es: Temperatura

## fields

### temperature

- id: temperature
- fieldType: decimal
- modifier: forCompute
- keyboardType: temperature

#### label

- fr: Température
- en: Temperature
- es: Temperatura

#### question

- fr: Quelle est la température à convertir?
- en: What is the temperature to convert?
- es: ¿Cuál es la temperatura a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de température: Celsius (°C) et Fahrenheit (°F).
- en: **{name}**{_newline}Temperature Converter: Celsius (°C) and Fahrenheit (°F).
- es: **{name}**{_newline}Convertidor de unidades de temperatura: Celsius (°C) y Fahrenheit (°F).
