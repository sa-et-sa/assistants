# mass_converter

## icon

- name: ⚖️

## category

- type: calculator

## name

- fr: Masse
- en: Mass
- es: Masa

## fields

### mass

- id: mass
- fieldType: decimal
- modifier: forCompute
- keyboardType: mass

#### label

- fr: Masse
- en: Mass
- es: Masa

#### question

- fr: Quelle est la masse à convertir?
- en: What is the mass to convert?
- es: ¿Cuál es la masa a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de masse: kilogrammes (kg), livres (lb), onces (oz), grammes (g).
- en: **{name}**{_newline}Mass Converter: kilograms (kg), pounds (lb), ounces (oz), grams (g).
- es: **{name}**{_newline}Convertidor de unidades de masa: kilogramos (kg), libras (lb), onzas (oz), gramos (g).
