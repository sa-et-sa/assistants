# weather_pressure_converter

## icon

- name: 🌦️

## category

- type: calculator

## name

- fr: Pression météorologique
- en: Weather Pressure
- es: Presión meteorológica

## fields

### weather_pressure

- id: weather_pressure
- fieldType: decimal
- modifier: forCompute
- keyboardType: weatherPressure

#### label

- fr: Pression atmosphérique
- en: Atmospheric Pressure
- es: Presión atmosférica

#### question

- fr: Quelle est la pression atmosphérique à convertir?
- en: What is the atmospheric pressure to convert?
- es: ¿Cuál es la presión atmosférica a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de pression météorologique: kilopascal (kPa), hectopascal (hPa), pouce de mercure (inHg) et millibar (mbar).
- en: **{name}**{_newline}Weather pressure unit converter: kilopascal (kPa), hectopascal (hPa), inch of mercury (inHg) and millibar (mbar).
- es: **{name}**{_newline}Convertidor de unidades de presión meteorológica: kilopascal (kPa), hectopascal (hPa), pulgada de mercurio (inHg) y milibar (mbar).
