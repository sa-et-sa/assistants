# long_distance_converter

## icon

- name: 🛤️

## category

- type: calculator

## name

- fr: Distance longue
- en: Long Distance
- es: Larga distancia

## fields

### long_distance

- id: long_distance
- fieldType: decimal
- modifier: forCompute
- keyboardType: longDistance

#### label

- fr: Distance longue
- en: Long Distance
- es: Distancia larga

#### question

- fr: Quelle est la distance longue à convertir?
- en: What is the long distance to convert?
- es: ¿Cuál es la distancia larga a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de distance longue: kilomètres (km) et milles (mi).
- en: **{name}**{_newline}Long Distance Converter: kilometers (km) and miles (mi).
- es: **{name}**{_newline}Convertidor de distancia larga: kilómetros (km) y millas (mi).
