# short_distance_converter

## icon

- name: 📏

## category

- type: calculator

## name

- fr: Distance courte
- en: Short Distance
- es: Corta distancia

## fields

### short_distance

- id: short_distance
- fieldType: decimal
- modifier: forCompute
- keyboardType: shortDistance

#### label

- fr: Distance courte
- en: Short Distance
- es: Distancia corta

#### question

- fr: Quelle est la distance courte à convertir?
- en: What is the short distance to convert?
- es: ¿Cuál es la distancia corta a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de distance courte: centimètres (cm), mètres (m), pieds (ft) et pouces (in).
- en: **{name}**{_newline}Short Distance Converter: centimeters (cm), meters (m), feet (ft), inches (in).
- es: **{name}**{_newline}Convertidor de unidades de distancia corta: centímetros (cm), metros (m), pies (ft), pulgadas (in).
