# volume_converter

## icon

- name: 🧪

## category

- type: calculator

## name

- fr: Volume
- en: Volume
- es: Conversión

## fields

### volume

- id: volume
- fieldType: decimal
- modifier: forCompute
- keyboardType: volume

#### label

- fr: Volume
- en: Volume
- es: Volumen

#### question

- fr: Quel est le volume à convertir?
- en: What is the volume to convert?
- es: ¿Cuál es le volumen a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Convertisseur d'unités de volume: litre (L), gallon impérial (gal imp.), gallon américain (gal US), litres (L) et tasses (tasses).
- en: **{name}**{_newline}Volume unit converter: liter (L), imperial gallon (gal imp.), US gallon (gal US), liters (L) and cups (cups).
- es: **{name}**{_newline}Convertidor de unidades de volumen: litro (L), galón imperial (gal imp.), galón estadounidense (gal US), litros (L) y tazas (tazas).
