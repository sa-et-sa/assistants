# pressure_converter

## icon

- name: 🌊

## category

- type: calculator

## name

- fr: Pression
- en: Pressure
- es: Presión

## fields

### pressure

- id: pressure
- fieldType: decimal
- modifier: forCompute
- keyboardType: pressure

#### label

- fr: Pression
- en: Pressure
- es: Presión

#### question

- fr: Quelle est la pression à convertir?
- en: What is the pressure to convert?
- es: ¿Cuál es la presión a convertir?

#### justification

- fr: Choississez l'unité de mesure à convertir. Entrez la valeur à convertir. Appuyez sur le bouton 📤 pour obtenir le résultat.
- en: Choose the unit of measure to convert. Enter the value to convert. Press the 📤 button to get the result.
- es: Elija la unidad de medida a convertir. Introduzca el valor a convertir. Presione el botón 📤 para obtener el resultado.

#### answer

- answerType: number

##### numberValidation

- precision: 4

## output

- outputType: none

### noResultFormat

- fr: **{name}**{_newline}Converisseur d'unité de pression: kilopascal (kPa) et livre par pouce carré (psi).
- en: **{name}**{_newline}Pressure unit converter: kilopascal (kPa) and pound per square inch (psi).
- es: **{name}**{_newline}Conversor de unidades de presión: kilopascal (kPa) y libra por pulgada cuadrada (psi).
