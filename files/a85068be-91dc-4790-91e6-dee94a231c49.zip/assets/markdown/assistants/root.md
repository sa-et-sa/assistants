# Documentation vivante de la définition d'un assistant (ce fichier est aussi un assistant)

Les paragraphes écrits ici sont traités comme des commentaires.

Notre algorithme les détecte, mais ne les utilise pas pour le paramétrage de l'assistant.

On peut donc s'en servir pour ajouter des notes, des exemples, des explications, etc.

On peut également ajouter des sections à nos documents qui n'ont pas d'influence sur le fonctionnement de l'assistant.

La section suivante est un exemple de section qui n'est pas utilisée par l'assistant, car son titre n'est pas reconnu par l'algorithme.

## identifiant (non reconnu)

L'identifiant d'un assistant est tout simplement son nom de fichier, sans l'extension `.md`.

On peut répéter cet identifiant comme titre principal de l'assistant, mais on peut également utiliser un titre plus explicite.

Les prochaines sections qu'on va ajouter seront des sections reconnues par l'assistant.

## icon

Pour le moment, nous utilisons un emoji pour définir l'icône de l'assistant.

La ligne suivante va être reconnue par l'algorithme et utiliser l'emoji spécifié par la propriété `name` comme icône de l'assistant dans l'application :

- name: 🤖

### refactoring de l'icône (non reconnu)

Une façon alternative, à implémenter, serait d'avoir un fichier d'icônes qui serait chargé par l'application et qui permettrait de définir l'icône de l'assistant selon son identifiant. Voir [assistant-icons.md](assistant-icons.md) pour plus de détails.

## name

Le nom de l'assistant est défini par la section `name` sous forme de propriétés multilingues (`L10nDefinition`).

On utilise une liste de propriétés pour définir le nom de l'assistant dans plusieurs langues.

Pour ce faire, on doit utiliser le code de la langue comme clé de la propriété.

La ligne suivante va être reconnue par l'algorithme et spécifier le nom de cet assistant dans les langues française `fr`, anglaise `en` et espagnole `es` :

- fr: Racine
- en: Root
- es: Raíz

### refactoring du nom (non reconnu)

Une façon alternative, à implémenter, serait d'avoir un fichier de noms d'assistant qui serait chargé par l'application et qui permettrait de définir le nom de l'assistant selon son identifiant. Voir [assistant-names.md](assistant-names.md) pour plus de détails.

## category

La catégorie de l'assistant est définie par la section `category`. La catégorie permet d'introduire un traitement spécifique pour un assistant.

La ligne suivante permet de définir une catégorie pour cette assistant :

- type: other

Les prochaines sections ne seront pas reconnues par l'algorithme. Elles sont titrées du mot clé définissant chacune des catégories et nous permettent de définir de définir plus précisément chaque catégorie.

### other (non reconnu)

La catégorie `other` est utilisée pour les assistants qui ne rentrent pas dans les autres catégories. C'est la catégorie par défaut, si aucune valeur de catégorie n'est spécifiée.

Les réponses d'un assistant de cette catégorie ne sont pas enregistrées.

En fait, il serait préférable de ne pas la spécifier, car le descriptif est peut-être mal choisi. Et ne pas la spécifier permettrait de ne pas introduire de dépendances à cette valeur dans le code.

### inventory (non reconnu)

Contrairement à la catégorie `other`, les réponses d'un assistant de la catégorie `inventory` sont enregistrées.

Outre cette nuance, le comportement de ces assistants est similaire à ceux de la catégorie `other`.

### equipment (non reconnu)

La catégorie `equipment` est utilisée pour les assistants qui gèrent des équipements.

Comme pour les assistants de la catégorie `inventory`, les réponses d'un assistant de la catégorie `equipment` sont enregistrées.

De plus les assistants de cette catégorie peuvent être soumis à un traitement spécifique. Cependant, aucun traitement spécifique n'est défini pour le moment.

### refactoring de catégory (non reconnu)

- [ ] Retirer  `other` de toutes les définitions d'assistant.
- [ ] Renommer la catégorie `other` en `default`.
- [ ] Retirer les classes `InventoryAssistantProperties` et `EquipmentAssistantProperties`, afin de n'utiliser que `GenericAssistantProperties`.
- [ ] Adapter la propriété `viewType` afin qu'elle retourne la bonne valeur selon la catégorie de l'assistant.

## fields

Cet assistant ne contient pas d'exemple pour cette section. Pour voir un exemple d'assistants documentant le fonctionnement des fields, voir le fichier [user/user.md](./user/user.md).

## assistant-fields

Cet assistant ne contient pas d'exemple pour cette section. Pour voir un exemple d'assistants documentant le fonctionnement des `assistant-fields`, voir le fichier [home/home.md](./home/home.md).

## onboarding-fields

Cet assistant ne contient pas d'exemple pour cette section. Pour voir un exemple d'assistants documentant le fonctionnement des `onboarding-fields`, voir le fichier [user/user.md](./user/user.md).

### related-assistants

Cet assistant ne contient pas d'exemple pour cette section. Pour voir un exemple d'assistants documentant le fonctionnement des `related-assistants`, voir le fichier [home/home.md](./home/home.md).

## modules

Les modules sont un ensemble d'assistants qui sont :

1. regroupés dans un même dossier
2. dont l'assistant principal possède également le même nom que le dossier.

Ainsi, `import/import.md` est l'assistant principal du module `import`.

Les modules peuvent également être déclarés dans une des 2 sections suivantes :

1. `primary-tools` afin de définir les outils principaux de l'assistant. Ils apparaîtront dans la barre de l'assistant sous forme d'icônes.
2. `secondary-tools` afin de définir les outils secondaires de l'assistant. Ils apparaîtront dans la barre de l'assistant sous le menu trois points.

Dans ce fichier, nous déclarons les modules qui n'apparaissent pas dans les sections `primary-tools` ou `secondary-tools` d'aucun assistant, mais qui doivent être chargés en mémoire afin d'assurer le bon fonctionnement de l'application.

*Cela est notamment dû au fait que les déclarations de `primary-tools` et `secondary-tools` ne sont pas encore utilisées par l'application qui les utilise en validant le nom de l'assistant.*

*Bien que le concept de modules ne disparaîtra pas de l'application, la déclaration de modules dans un assistant, elle, devrait disparaître avec l'utilisation de `primary-tools` et `secondary-tools`.*

Les prochains titres de niveau 3 (`###`) vont être reconnus par l'algorithme et charger les modules correspondants en mémoire.

### user

### home

### import

### delete

### container_filling
