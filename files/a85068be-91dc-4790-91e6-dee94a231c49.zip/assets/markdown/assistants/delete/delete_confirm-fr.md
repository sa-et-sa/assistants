---
title: Suppression
ok-button: "Confirmer"
cancel-button: "Annuler"
---

Confirmez vous la suppression de l'élément ?
