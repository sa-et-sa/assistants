---
title: Eliminación
ok-button: "Confirmar"
cancel-button: "Cancelar"
---

¿Confirma la eliminación del elemento?
