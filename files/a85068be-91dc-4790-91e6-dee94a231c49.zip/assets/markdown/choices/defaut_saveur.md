# defaut_saveur

## name

- fr: Liste des défauts de saveur
- en: List of flavor defects
- es: Lista de defectos de sabor

## fields

### none

- id:none
- fieldType: text

#### label

- fr: Aucun
- en: None
- es: Ninguno

### tick

- id:tick
- fieldType: text

#### label

- fr: Crochet
- en: Crochet
- es: Crochet

### vr1

- id:vr1
- fieldType: text

#### label

- fr: VR1 - Origine naturelle
- en: VR1 - Natural origin
- es: VR1 - Origen natural

### vr2

- id:vr2
- fieldType: text

#### label

- fr: VR2 - Origine microbienne
- en: VR2 - Microbial origin
- es: VR2 - Origen microbiano

### vr3

- id:vr3
- fieldType: text

#### label

- fr: VR3 - Origine chimique
- en: VR3 - Chemical origin
- es: VR3 - Origen químico

### vr4

- id:vr4
- fieldType: text

#### label

- fr: VR4 - Origine technique
- en: VR4 - Technical origin
- es: VR4 - Origen técnico

### vr5

- id:vr5
- fieldType: text

#### label

- fr: VR5 - Goût de bourgeon
- en: VR5 - Bud taste
- es: VR5 - Sabor a brote

### ct

- id:ct
- fieldType: text

#### label

- fr: CT - Transformation
- en: CT - Transformation
- es: CT - Transformación

### noIdea

- id:noIdea
- fieldType: text

#### label

- fr: Ne sait pas
- en: No idea
- es: No idea

## output

- outputType: reference

### outputFormat

- fr: {name}
- en: {name}
- es: {name}
